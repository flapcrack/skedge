//document.onreadystatechange = function() {	
//	if (document.readyState == "complete") {
//		initPW();
//	}
//}

var PW;
var PC;
function initPW() {
	PW=document.body.getElementsByClassName('pw')[0];
	PC=document.body.getElementsByClassName('pc')[0];
	Snap(PW).click(function(){showPartwriter();})
	Snap(PC).click(function(){showPartchecker();})
	S=Snap(window.innerWidth*0.9,window.innerHeight);
	if (!handler) stripeConfigure();
}

var GS;
function showPartwriter() {
	dimPs();
	setTimeout(function(){
		GS = new grandStaff(0,0, 720);
		document.title='Partwriter';
	},500);
}

function showPartchecker() {
	dimPs();
}

function dimPs() {
	Snap(PW).animate({opacity:0},500,null,function() {this.attr({display:'none'})});
	Snap(PC).animate({opacity:0},500,null,function() {this.attr({display:'none'})});
	setTimeout(function() {Snap('#chooser').attr({display:'none'})},500)
}

function showPs() {
	Snap(PW).attr({display:''}).animate({opacity:1},500);
	Snap(PC).attr({display:''}).animate({opacity:1},500);
}

function MYstaff(n, ts, w) {
	var h = 100, mrg = 0;
	//n = n * 1.1;
	var y = 30 * 5 * (n * 1.5 + 1);
	var dis=this;
	this.lines=[];
	this.sharps=[];
	this.flats=[];
	this.width = w;
	this.whole = S.group();
	for (var i = 0; i < 5; i++) {
		this.lines[i]=S.rect(mrg, y+i*h/5, w, 0.125).attr({stroke:"black"});
		this.whole.append(this.lines[i]);
		//y += h / 5;
	}
	//S.rect(mrg,y,2,h*4/5).attr({stroke:"black"});	// Begin Bar
	//S.rect(w-8,y,2,h*4/5).attr({stroke:"black"});	// End Bars
	//S.rect(w,y,8,h*4/5).attr({stroke:"black"});

	// Draw clef
	var p;
	if (n == 0) {									// Treble
		this.clef = this.whole.path(treblePath).attr({fill: "black"}).transform("translate(15, 212) scale(0.070, -0.070)");
	} else {										// Bass
		this.clef = this.whole.path(bassPath).attr({fill: "black"}).transform("translate(15, 396) scale(0.074, -0.074)");
	}
	//transform("translate(20, 212) scale(0.004, -0.004");
	// Time Signature
	/*var tsig;
	Object.defineProperty(this, "timeSig", {
		get: function() { return tsig; },
		set: function(v) {
			var vals = v.split('\/');
			if (vals.length != 2) return;
			var t, p, ty;
			for (var i = 0; i < vals.length; i++) {
				if (vals[i] == '3') {
					t = "translate(75, yy) scale(0.08, -0.08)".replace("yy", (y+40).toString());
					p = S.path(path3).attr({fill: "black"}).transform(t);	// 3
				} else {
					t = "translate(70, yy) scale(0.08, -0.08)".replace("yy",  (y+80).toString());
					p = S.path(path4).attr({fill: "black"}).transform(t);	// 4
				}
			}
		}
	});
	this.timeSig = ts || "4/4";*/
	//set up time signature
	this.tsig = new tSig(n, ts, this, "C");
	//this.tsigB = new tSig(1, ts, this.clef, "C");	

	// Add / Draw Notes
	this.beats = [];
	this.addNotes = function(nts,b) {
		this.beats.push(nts);
	}
	this.drawNotes = function() {
		var nts, nt, nd, ny, nx, oct, t, p, r;
		for (var i = 0; i < this.beats.length; i++) {
			nts = this.beats[i];		// Array of notes this beat
			for (var j = 0; j < nts.length; j++) {
				nt = nts[j] - 60;
				oct = Math.floor(nt/12);
				nd = nts[j] % 12;
				if (nd < 0) nd += 12;
				ny = 250 - nad[nd][0] * 10 - oct * 10 * 7;
				nx = i * 62 + 240;
				t = "translate(xx, yy) scale(0.07, -0.07)".replace("xx", nx.toString()).replace("yy", ny.toString());
				p = S.path(closedPath).attr({fill: "black"}).transform(t);
				if (nad[nd][1] != 0)
					sharp(nt+60, i);
				if (nad[nd][0] <= 2)
					r = S.rect(nx+0.6,ny+2,2,45);		// Down Stem
				else
					r = S.rect(nx+20.5,ny-45,2,45);		// Up Stem
				if (nad[nd][0] == 0)
					r = S.rect(nx-12,ny,48,2);			// Note Middle Line
				//if (nad[nd][1] != 0)
				//	sharp(s,nt+60,i);
			}
		}
	}
	this.whole = S.group(dis.clef,dis.lines[0],dis.lines[1],dis.lines[2],dis.lines[3],dis.lines[4],this.tsig.whole);
}

var currentCHP;
var INPUTS=[[],[],[],[],[],[],[]];
var mINPUTS=[[],[],[],[],[],[],[]];
function grandStaff(xi, yi, w) {
	//set up staffs
	var dis=this;
	this.width = w;
	this.trebleStaff = new MYstaff(0, "4/4", w);
    this.hrects=[];	
    
    //notes
    this.basses=[];
    this.tenors=[];
    this.altos=[];
	this.sopranos=[];
	
	this.startNotes=[];
    
    this.noteAry = [this.basses, this.tenors, this.altos, this.sopranos];
    this.getNotes=function() {
		for (var i=0; i<4; i++) {
			for (var j=0; j<this.basses.length; j++) {
				INPUTS[j][i] = this.noteAry[i][j].name;
				mINPUTS[j][i] = this.noteAry[i][j].midiNbr;
			}
		}
	}
    
	this.bassStaff = new MYstaff(1, "4/4", w);
	this.centerStaff = function() {
		this.whole.animate({transform:'t'+(window.innerWidth/2-this.width/2)+' '+(window.innerHeight/2-350)+' s1.1'},200,mina.backout);
		//Snap.animate(0,window.innerWidth/2-this.width/2,function(val){dis.whole.attr({transform: 't'+val+' -20 s1.1'})},200,mina.backout);
		//Snap.animate(0,0.1,function(val){staffGroup.attr({transform: 't0 0 s' + val})},900);
		this.keyMenu.key.animate({opacity:1},200);
		setTimeout(function() {
			for (var i=0; i<dis.hrects.length; i++) {
				dis.hrects[i].r.transform('t'+dis.trebleStaff.sharps.length*18+' 0');
			}
		},400);	
		//this.whole.transform('t'+(window.innerWidth/2-this.width/2)+' 0 s1.1');
	}
	this.brace = this.trebleStaff.whole.path(bracePath).attr({transform:'t100 302.55 s0.07108 -0.07108',fill:rnGrad2});
	this.leftRect = this.trebleStaff.whole.rect(-1,149,3,307);
	this.endBar = this.trebleStaff.whole.rect(w,149,7,307);
	this.endBar2 = this.trebleStaff.whole.rect(w-6,149,2,307);
	
	this.barLine = this.trebleStaff.whole.rect(430,149,2,307);
	
	//chord prompts
	this.chps = [];
	for (var i=0; i<4; i++)
		this.chps.push(new rLab(xi+i*70, yi+15, this.trebleStaff.whole, this));
	for (var j=i; j<7; j++)
		this.chps.push(new rLab(xi+i*70+(j-4)*70+20, yi+15, this.trebleStaff.whole, this));
	
	this.setKey = function(key) {
		setSig(key, this.trebleStaff, this.bassStaff);
	}
	//this.moveStaff = function(x, y) {
	//	this.trebleStaff.whole.transform('t'+x+' '+y);
	//	this.bassStaff.whole.transform('t'+x+' '+y);
	//}
	
	this.t1tog='4';
	this.dimStaff = function(op) {
		var tog = op ? 1 : 0.1;
		var childrens = this.bassStaff.whole.node.children;
		var nfo1, nfo2;
		for (var i=0; i<childrens.length; i++) {
			nfo1 = childrens[i].getAttribute('height');
			nfo2 = childrens[i].getAttribute('width');
			if (nfo1 == 40 && nfo2 == 40) continue;
			Snap(childrens[i]).attr({opacity:tog});
		}
	}
	
	//key label
	//this.keyRect = new keyRect(this.bassStaff);
	var stf = this.bassStaff.whole;
    var x = getBass(stf).transform.baseVal[0].matrix.e + 8;
    var y = getBass(stf).transform.baseVal[0].matrix.f + 90;	
	this.keyMenu=new keyMenu(x+47.5,y+130,stf,this);
	
	this.whole = S.group(this.bassStaff.whole,this.trebleStaff.whole);
	var count=0;
	//for (var j=0; j<7; j++) {
		for (var i=4; i<38; i++) {
			this.hrects.push(new fbHover(this.trebleStaff,i,this));
			this.whole.append(this.hrects[count].whole);
			count++;
		} 
	//}
	this.swbxs = []; 
	for (var i=0; i<this.chps.length; i++) {
		this.whole.append(this.chps[i].whole);
		this.swbxs.push(this.chps[i].swbx);
	}
	this.whole.append(this.keyMenu.whole);
						 
	this.keyMenu.key.node.childNodes[0].data="C";
	this.keyMenu.key.animate({opacity:1},500);
	this.keyMenu.centerKey();
	
	this.check = this.whole.rect(0,98.5,50,20,5);
	this.checkTxt = this.whole.text(5,114,'Check').attr({fill:'white'});
	this.checkClr = this.whole.rect(0,98.5,50,20).attr({opacity:0});
	var chg = S.group(this.check,this.checkTxt,this.checkClr);
	chg.attr({display:'none'});
	this.checkClr.click(
		function() {
			checkSolution();
		}
	)
	
	//solver button
	var solveButton = S.image('images/pw.png');
	var mask = S.circle(64,64,64).attr({fill:'#FFF'});
	solveButton.attr({mask:mask});
	solveButton.transform('s0.4');
	var solve = S.text(8,70,'solve').attr({display:'none',fontFamily:'arial'});
	var sg = S.group(solveButton,solve);
	sg.transform('t-100 280')
	this.whole.append(sg);
	solveButton.hover(
		function() {solve.attr({display:''})},
		function() {solve.attr({display:'none'})}
	)
	solveButton.click(
		function() {
			solve.attr({display:'none'});
			//if (checkProg())
			runSolver();
			//else
			//	notEnough();
		}
	)
	
	var runSolver = function() {
		console.log('sending to server')
		var obj = {};
		obj.chords=getProgression();
		obj.key=getData(GS.keyMenu.key);
		obj.startNotes=[];
		for (var i=0; i<GS.startNotes.length; i++)
			obj.startNotes.push(GS.startNotes[i].midiNbr);
		xhrPOST('/solve',JSON.stringify(obj),handleSolve);
	}

	var handleSolve = function(txt) {
		if (txt=='OK') {
			console.log('display solution');
		} else {
			var js = JSON.parse(txt);
			if (js.msg) {
				if (js.msg=='need to buy') {
					handler.open({
						name: 'partwriting.com',
						description: 'Partwriter full license',
						amount: 500
					});
				}
			}
		}
	}
	
	var notEnough = function() {
		console.log('not enough chords')
	}
	
	var checkProg = function() {
		var uprg = getProgression();
		for (var i=0; i<uprg.length; i++) {
			if (uprg[i]==' ') return false;
		}
		return true;
	}
	this.centerStaff();
	this.price=500;
	this.sku='partwriter';
	//this.whole.append(this.check);
	//this.setKey("C");
	//this.bassStaff.append(this.keyMenu.whole);
}

var KEYMENUOPEN=false;
function keyMenu(x,y,stf,parent) {
    var dis=this;
    //this.note=cn;
    this.hoverX;
    this.hoverY;
    //this.base=S.text(x-20,y+30,"____ :").attr({fill:"#3ecc67","font-size":"18px"});
    var baseW=40;
    this.baseWidth=baseW;
    this.base=stf.line(x-20,y+35,x+20,y+35).attr({stroke:'#3ecc67',display:'none'});

    //this.dragLine;

    //this.relBrackets=S.text(x-20,y+56,"[\u00A0\u00A0\u00A0]").attr({fill:"#3ecc67","font-weight":"bold","font-size":"16px"});
    //this.relBrackets.transform('t'+(baseW/4)+' 0');
    //this.relclr=S.rect(x-20,y+44,2*this.relBrackets.getBBox().width,22).attr({opacity:'0.0'});
    /*this.relclr.click(
        function() {
			if (DISC_PROC!="Tonal Center") return;
            switch(dis.numTog) {
                case true:
                    break;
                case false:
                    if (!dis.brackMenu) {
                        dis.brackMenu=new brackMenu(x,y,cn,dis);
                        //dis.whole.append(dis.brackMenu.whole);
                    }
                    else {
                        dis.brackMenu.bTog=!dis.brackMenu.bTog;
                        switch(dis.brackMenu.bTog) {
                            case false:
                                dis.brackMenu.relHide();
                                break;
                            case true:
                                dis.brackMenu.relShow();
                                break;
                        }
                    }
                    break;
            }
        }
    )*/

    //this.baseArrow=S.text(x-35,y+28.5,'\u2794').attr({fill:"#3ecc67","font-weight":"bold","font-size":"14px",opacity:'0.0'});
    //this.baseArrow=S.path(towardsPath).attr({fill:"#3ECC67",opacity:0.0,transform:'t'+(x-35)+' '+(y+28.5)+' s2'});
    //this.baseArrowclr=S.rect(x-37,y+10,18,25,0).attr({opacity:'0.0'});
    this.key=stf.text(x-20,y+29," ").attr({fill:"black","font-weight":"bold","font-size":"18px",opacity:'0.0',"font-family":"arial"});
    this.colon=stf.text(x+10,y+28,":").attr({fill:"black","font-weight":"bold","font-size":"18px","font-family":"arial"});

    //this.arrowback=S.rect(x-38,y-63,30,15,5).attr({fill:"white",stroke:"#989898"});
    //this.arrow=S.text(x-22,y-49.5,'\u2794').attr({fill:"#3ecc67","font-weight":"bold","font-size":"14px"});
    //this.arrow=S.path(towardsPath).attr({fill:"#3EEC67",transform:'t'+(x-21)+' '+(y-51)+' s1.1 1.4'});
    //this.arrowButton=S.rect(x-38,y-63,15,15,5).attr({fill:"#E7E7E7",stroke:"#989898"});
    //this.arrowclr=S.rect(x-40,y-65,34,19,0).attr({opacity:'0.0'});
    //this.aTog=false;
    /*this.arrowclr.click(
        function() {
            dis.aTog=!dis.aTog;
            switch(dis.aTog) {
                case true:
                    dis.arrowButton.animate({transform:'t15 0'},100);
                    dis.baseArrow.animate({opacity:'1.0'},100);
                    //dis.baseArrow.transform('t'+(baseW/2-dis.key.getBBox().width/2)+' 0');
                    break;
                case false:
                    dis.arrowButton.animate({transform:'t0 0'},100);
                    dis.baseArrow.animate({opacity:'0.0'},100);
                    break;
            }
        }
    )*/
    //this.arrowGroup=S.group(this.arrowback,this.arrowButton,this.arrow,this.arrowclr);
    this.padback=stf.rect(x-8,y-65,36,19,5).attr({fill:rnGrad3});
    this.Mmback=stf.rect(x-6,y-63,32,15,5).attr({fill:"white",stroke:"#989898",strokeWidth:0.1});
    this.M=stf.text(x-3.25,y-51,"M").attr({fill:"black","font-weight":"bold","font-size":"11px",fontFamily:'arial'});
    this.m=stf.text(x+12.25,y-51,"\u02A4").attr({fill:"black","font-weight":"bold","font-size":"11px",fontFamily:'taFont'});
    this.MmButton=stf.rect(x-6,y-63,15,15,5).attr({fill:"#E7E7E7",stroke:"#989898",strokeWidth:0.4});
    this.Mmclr=stf.rect(x-8,y-65,34,19,0).attr({opacity:'0.0'});
    this.MmTog=false;
    this.Mmclr.click(
        function() {
            dis.MmTog=!dis.MmTog;
            switch(dis.MmTog) {
                case true:
                    dis.MmButton.animate({transform:'t16.5 0'},100);
                    for (var i=0; i<dis.romAry.length; i++) {
                        dis.romAry[i].node.childNodes[0].data=dis.mroms[i];
                        dis.romAry[i].rect.node.setAttribute("width",dis.romAry[i].getBBox().width+5);
                    }
                    break;
                case false:
                    dis.MmButton.animate({transform:'t0 0'},100);
                    for (var i=0; i<dis.romAry.length; i++) {
                        dis.romAry[i].node.childNodes[0].data=dis.Mroms[i];
                        dis.romAry[i].rect.node.setAttribute("width",dis.romAry[i].getBBox().width+5);
                    }
                    break;
            }
        }
    )

    //this.secTonback=stf.rect(x+26,y-63,30,15,5).attr({fill:"white",stroke:"#989898"});
    //this.secTon=stf.text(x+47,y-53,":").attr({fill:"#3ecc67","font-weight":"bold","font-size":"11px"});
    //this.secTonButton=stf.rect(x+41,y-63,15,15,5).attr({fill:"#E7E7E7",stroke:"#989898"});
    //this.secTonclr=stf.rect(x+24,y-65,34,19,0).attr({opacity:'0.0'});
    //this.secTonTog=true;
    /*this.secTonclr.click(
        function() {
            dis.secTonTog=!dis.secTonTog;
            switch(dis.secTonTog) {
                case false:
                    dis.secTonButton.animate({transform:'t-15 0'},100);
                    if (dis.dragLine) {
                        dis.dragLine.whole.remove();
                    }
                    dis.dragLine=new makeDragLine(x-20,y+35,x+20,y+35,dis);
                    dis.dragLine.whole.attr({display:""});
                    dis.dragLine.romNom.node.childNodes[0].data=dis.relBrackets.node.childNodes[0].data;
                    dis.dragLine.romNom.transform('t'+(20-dis.dragLine.romNom.getBBox().width/2)+' 0');
                    dis.dragLine.romclr.transform('t0 0');
                    setTimeout(function() {
                        dis.dragLine.whole.animate({transform:"t28 -30"},500,mina.backout);
                    },75);
                    dis.colon.attr({display:"none"});
                    dis.base.attr({display:"none"});
                    dis.key.attr({display:"none"});
                    dis.relBrackets.attr({display:"none"});
                    dis.relclr.attr({display:"none"});
                    dis.numeralC.attr({display:"none"});
                    dis.baseArrow.attr({display:"none"});
                    dis.romMenuHide();
                    //S.append(dis.dragLine.whole);
                    /*} else {
                        dis.dragLine.whole.attr({display:""});
                        dis.dragLine.whole.animate({transform:"t30 -50"});
                        dis.base.attr({display:"none"});
                        dis.key.attr({display:"none"});
                        dis.relBrackets.attr({display:"none"});
                        dis.relclr.attr({display:"none"});
                        dis.numeralC.attr({display:"none"});
                        dis.romMenuHide();
                    }*/
                    /*break;
                case true:
                    dis.secTonButton.animate({transform:'t0 0'},100);
                    break;
            }
        }
    )*/

    this.padGroup=stf.group(this.padback,
                          this.Mmback,this.MmButton,this.M,this.m,this.Mmclr
                          //this.secTonback,this.secTonButton,this.secTon,this.secTonclr
                          ).attr({opacity:0,display:'none'});
    this.numeralC=stf.rect(x-23,y+6,51,33).attr({opacity:'0.0'});
    this.numeralC.hover(
		function() {
			for (var i=0; i<GS.hrects.length; i++) {
				if (GS.hrects[i].note) {
					GS.hrects[i].note.remove();
					GS.hrects[i].note=null;
				}
				if (GS.hrects[i].ledgers) {
					for (var j=0; j<GS.hrects[i].ledgers.length; j++)
						GS.hrects[i].ledgers[j].remove();
				}
			}
		},
		function() {},
		null,null
    )
    this.numeralC.click(
        function() {
			if (RMENUOPEN) return;
			//if (LAYER!="s") return;
			//if (DISC_PROC!="Tonal Center") return;
            dis.numTog=!dis.numTog;
			/*var scr = 0;
			if (cn.staff%2==1)
				switch(score.length) {
					case 1:
						scr=0;
						break;
					case 2:
						scr=1;
						break;
				}
			*/
            switch(dis.numTog) {
                case true:
                    dis.romMenuShow();
					GS.dimStaff(0);
					dimRlabs(0,0);
                    break;
                case false:
                    if (dis.key.node.childNodes[0].data==" ") {
                        dis.romMenuHide(); dis.numTog=false;
                        //dealWithRemovingKey(parent.index);
                        //score[scr].Notes[dis.note.keyRect.turnOff].keyRect.clr.attr({display:""});
                        //score[scr].Notes[dis.note.keyRect.turnOff+1].keyRect.clr.attr({display:""});
						//if (dis.note.keyRect.turnOff-2 > -1) score[scr].Notes[dis.note.keyRect.turnOff-2].keyRect.clr.attr({display:''});
						//if (dis.note.keyRect.turnOff-3 > -1) score[scr].Notes[dis.note.keyRect.turnOff-3].keyRect.clr.attr({display:''});                        
                        //setTimeout(function() {dis.note.keyRect.clr.attr({display:''}); dis.whole.remove(); dis.note.keyRect.keyMenu=null;},300);
                    } else {
                        dis.romMenuHide();
                    }
                    GS.dimStaff(1);
                    dimRlabs(0,1);
                    break;
            }
        }
    )
    //this.note=cn;

	//rom Wheel
	this.romAry=[];
	this.roms = ["C","G","D","A","E","B","F♯","D\u0231","A\u0231","E\u0231","B\u0231","F"];
	this.Mroms = ["C","G","D","A","E","B","F♯","D\u0231","A\u0231","E\u0231","B\u0231","F"];
	this.mroms = ["c\u02A4","g\u02A4","d\u02A4","a\u02A4","e\u02A4","b\u02A4","f♯\u02A4","c♯\u02A4","g♯\u02A4","e\u0231\u02A4","b\u0231\u02A4","f\u02A4"];
    var adds;
    for (var i=0; i<dis.roms.length; i++) {
        adds=0;
        dis.romAry[i]=stf.text(x-4,y+30,dis.roms[i]).attr({fill:'black','font-size':'11px',opacity:'0.0',display:"none","font-weight":"bold","font-family":"taFont"});
        if (this.roms[i].indexOf("♭")!=-1) adds=5;
        if (this.roms[i].indexOf("♯")!=-1) adds=3;
        dis.romAry[i].rect=stf.rect(x-6,y+15,15+adds,20,0).attr({opacity:'0.0',display:"none"});
        dis.romAry[i].rect.rom=dis.romAry[i];
        dis.romAry[i].rect.click(
            function(m) {
                var sm=Snap(m.target).rom;
                if (sm.node.childNodes[0].data==dis.key.node.childNodes[0].data) {
                    dis.key.node.childNodes[0].data=" ";
					//var ary = [0,0,1];
					//var n = ary[score.length];                    
                    //score[n].Notes[dis.note.keyRect.turnOff].keyRect.clr.attr({display:""});
                    //score[n].Notes[dis.note.keyRect.turnOff+1].keyRect.clr.attr({display:""});
					//if (dis.note.keyRect.turnOff-2 > -1) score[n].Notes[dis.note.keyRect.turnOff-2].keyRect.clr.attr({display:''});
					//if (dis.note.keyRect.turnOff-3 > -1) score[n].Notes[dis.note.keyRect.turnOff-3].keyRect.clr.attr({display:''});                    
                    //dis.key.transform('t'+((dis.base.getBBox().width-5)/2-dis.key.getBBox().width/2)+' 0');
                    dis.romMenuHide(); dis.numTog=false;
                    //setTimeout(function() {
					//	dis.note.keyRect.clr.attr({display:''}); dis.whole.remove(); dis.note.keyRect.keyMenu=null; dealWithRemovingKey(parent.index);
					//},300);
                    GS.dimStaff(1);
                    dimRlabs(0,1);
                    return;
                }
                switch(dis.MmTog) {
                    case true:
                        dis.key.attr({"font-size":"17px"});
                        break;
                    case false:
                        dis.key.attr({"font-size":"20px"});
                        break;
                }

                dis.key.node.childNodes[0].data=sm.node.childNodes[0].data;
                //setFollowChRects(parent.index,sm.node.childNodes[0].data);
				dis.centerKey();
				parent.setKey(sm.node.childNodes[0].data);
                //dis.key.transform('t'+((dis.base.getBBox().width-5)/2-dis.key.getBBox().width/2)+' 0');
                //dis.key.animate({opacity:'1.0'},200);
                dis.romMenuHide(); dis.numTog=false;
                GS.dimStaff(1);
                dimRlabs(0,1);
                //dis.baseArrow.transform('t'+(baseW/2-dis.key.getBBox().width/2)+' 0');
            }
        )
        dis.romAry[i].rect.hover(
            function(m) {

                var sm=Snap(m.target);
                    //dis.hoverX=sm.matrix.e;
                    //dis.hoverY=sm.matrix.f;
                sm.animate({transform:'t'+sm.rom.x+' '+sm.rom.y+' s1.4'},55);
                sm.rom.animate({transform:'t'+sm.rom.x+' '+sm.rom.y+' s1.4'},55);

            },
            function(m) {
                var sm=Snap(m.target);
                //var tx=sm.matrix.e;
                //var ty=sm.matrix.f;
                sm.animate({transform:'t'+sm.rom.x+' '+sm.rom.y+' s1'},45);
                sm.rom.animate({transform:'t'+sm.rom.x+' '+sm.rom.y+' s1'},45);
            },
            null,null
        )
        stf.group(dis.romAry[i],dis.romAry[i].rect);
    }
    this.centerKey = function() {
		this.key.transform('t'+(baseW/2-this.key.getBBox().width/2)+' 0');
	}
    this.pass=1;
    this.romMenuShow = function() {
        var alpha=0;
        var adds;
        var radius=60;
        var incr=(360/dis.romAry.length)*(3.14159/180);
        var newX, newY;
        for (var i=0; i<dis.romAry.length; i++) {
            adds=0;
            if ((dis.romAry[i].node.childNodes[0].data.indexOf("♭")!=-1)&&((dis.romAry[i].node.childNodes[0].data.indexOf("E")!=-1)||(dis.romAry[i].node.childNodes[0].data.indexOf("e")!=-1))) adds=-3;
            newX = radius*Math.cos(-i*incr);
            newY = radius*Math.sin(i*incr)+adds;
            dis.romAry[i].attr({display:""});
            dis.romAry[i].animate({transform:'t ' + newX + ' ' + newY},350,mina.backout);
            dis.romAry[i].animate({opacity:'1.0'},250);
            dis.romAry[i].attr({opacity:'1.0'});
            dis.romAry[i].rect.attr({display:""});
            dis.romAry[i].rect.attr({transform:'t ' + newX + ' ' + newY});
            if (dis.pass==1) {
                dis.romAry[i].rect.rom.x=newX;
                dis.romAry[i].rect.rom.y=newY;
            }
        }
        dis.padGroup.attr({display:''});
        dis.padGroup.transform('t-10 0');
        dis.padGroup.animate({opacity:'1.0'},350);
        dis.pass=2;
        KEYMENUOPEN=true;
        //fadeStaff(dis.note.staff,0);
        //fadeCode(dis.note.staff,0);
    };
    this.romMenuHide = function() {
        //CURRENT_NOTE.romBox.numeralCopen=!CURRENT_NOTE.romBox.numeralCopen;
        for (var i=0; i<dis.romAry.length; i++) {
            dis.romAry[i].animate({transform:'t0 0'},300,mina.backin);
            dis.romAry[i].animate({opacity:'0.0'},350);
            //dis.romAry[i].rect.animate({transform:'t0 0'},300,mina.backin);
        }
        dis.padGroup.animate({opacity:'0.0'},350);
        setTimeout(function() {
            for (var i=0; i<dis.romAry.length; i++) {
                dis.romAry[i].attr({display:'none'}); dis.romAry[i].rect.attr({display:"none"});
            }
            dis.padGroup.attr({display:'none'});
            dis.whole.append(dis.numeralC);
        },200);
        KEYMENUOPEN=false;
        //fadeStaff(dis.note.staff,1);
        //fadeCode(dis.note.staff,1);
    }
    this.whole=stf.group(this.base,this.key,this.colon,
                       this.romAry[0],this.romAry[1],this.romAry[2],this.romAry[3],this.romAry[4],
                       this.romAry[5],this.romAry[6],this.romAry[7],this.romAry[8],this.romAry[9],
                       this.romAry[10],this.romAry[11],
                       this.romAry[0].rect,this.romAry[1].rect,this.romAry[2].rect,this.romAry[3].rect,
                       this.romAry[4].rect,this.romAry[5].rect,this.romAry[6].rect,this.romAry[7].rect,
                       this.romAry[8].rect,this.romAry[9].rect,this.romAry[10].rect,this.romAry[11].rect,
                       this.numeralC,
                       this.padGroup
                       //this.baseArrow,this.baseArrowclr,this.relBrackets,this.relclr
                       );
    //var newX = this.whole.attr('transform').globalMatrix.e;
    //var newY = this.whole.attr('transform').globalMatrix.f;
    this.whole.transform('t0 -130 s1.5');
    this.numTog=false;
    //this.romMenuShow(); this.numTog=true;
}

function keySig(key) {
    var sig=[];
    switch(key) {
        case "C":
            break;
        case "G":
            sig=["F♯"];
            break;
        case "D":
            sig=["F♯","C♯"];
            break;
        case "A":
            sig=["F♯","C♯","G♯"];
            break;
        case "E":
            sig=["F♯","C♯","G♯","D♯"];
            break;
        case "B":
            sig=["F♯","C♯","G♯","D♯","A♯"];
            break;
        case "F♯":
            sig=["F♯","C♯","G♯","D♯","A♯","E♯"];
            break;
        case "C♯":
            sig=["F♯","C♯","G♯","D♯","A♯","E♯","B♯"];
            break;
        case "F":
            sig=["B♭"];
            break;
        case "B♭":
            sig=["B♭","E♭"];
            break;
        case "E♭":
            sig=["B♭","E♭","A♭"];
            break;
        case "A♭":
            sig=["B♭","E♭","A♭","D♭"];
            break;
        case "D♭":
            sig=["B♭","E♭","A♭","D♭","G♭"];
            break;
        case "G♭":
            sig=["B♭","E♭","A♭","D♭","G♭","C♭"];
            break;
        case "C♭":
            sig=["B♭","E♭","A♭","D♭","G♭","C♭","F♭"];
            break;
    }
    return sig;
}

function tSig(n, ts, stf, key) {
	var t1, t2;
	var m = 40; //numspace
	var sp = 225; //staffspace
	var ofs = 80;
	var x;
	var dis = this;
	switch(n) {
		case 0:
			x = stf.clef.attr('transform').globalMatrix.e - 115;
			break;
		case 1:
			x = stf.clef.attr('transform').globalMatrix.e - 115;
			break;
	}
	switch(ts) {
		case "4/4":
			this.t1 = stf.whole.path(fourPath).transform('t'+x+' '+(sp*n-ofs)+' s0.081 -0.081');
			this.t1Clr = stf.whole.rect(x+180,sp*n+150,40,40).attr({opacity:0.0});
			this.t2 = stf.whole.path(fourPath).transform('t'+x+' '+(m+sp*n-ofs)+' s0.081 -0.081');
			this.t2Clr = stf.whole.rect(x+180,m+sp*n+150,40,40).attr({opacity:0.0});
			break;
	}
	//this.t1tog='4';
	this.t1Clr.click(
		function() {
			return;
			var m=4;
			switch(GS.t1tog) {
				case '4':
					GS.trebleStaff.tsig.t1.attr({d:threePath});
					moveEle(GS.trebleStaff.tsig.t1,m,0);
					//GS.trebleStaff.tsig.t1.transform('t2 0 s0.081 -0.081');
					GS.bassStaff.tsig.t1.attr({d:threePath});
					moveEle(GS.bassStaff.tsig.t1,m,0);
					//GS.bassStaff.tsig.t1.transform('t2 0 s0.081 -0.081');
					GS.t1tog='3';
					break;
				case '3':
					GS.trebleStaff.tsig.t1.attr({d:fourPath});
					moveEle(GS.trebleStaff.tsig.t1,-m,0);
					GS.bassStaff.tsig.t1.attr({d:fourPath});
					moveEle(GS.bassStaff.tsig.t1,-m,0);
					GS.t1tog='4';
					break;
			}
		}
	)
	this.whole = S.group(this.t1,this.t2,this.t1Clr,this.t2Clr);
}

var lastClicked;
function rLab(x,y,parent,prnt) {
	this.parent = parent;
	this.mtog=false;
	var dis = this;
	x+=105; y+=245;
	this.rMenu = new rMenu(x+10,y+200,0,this);
	this.modMenu = new modMenu(x+10,y+200,this);
	//this.modMenu.show();
	this.line = parent.rect(x+50,y+290,40,1);
	this.label = parent.text(x+50,y+284,' ').attr({fontSize:'18px','font-family':'myFirstFont'});
	this.inv = "";
	this.mod = "";
	this.SD=0;
	this.centerLabel = function() {
		var ww;
		if (this.clr)
			ww = this.clr.attr('width')/2;
		else
			ww = 20;
		this.label.transform('t'+(ww-this.label.getBBox().width/2)+' '+(-this.SD*14));
	}
	this.centerLabel();
	this.arrowUp = parent.polyline(x+94,y+277, x+98,y+275, x+102,y+277).attr({fill:'none',stroke:'black',strokeWidth:2});
	this.arrowUpClr = parent.rect(x+90,y+268,18,13).attr({opacity:0.0});
	this.arrowUpClr.hover(
		function() {
			dis.modMenu.onSum=true;
			for (var i=0; i<GS.chps.length; i++)
				if (GS.chps[i].rMenu.menuTog) return;
			dis.arrowUp.transform('t0 0 s1.2');
			dis.arrowUpClr.transform('t0 0 s1.2');
		},
		function() {
			dis.modMenu.onSum=false;
			dis.arrowUp.transform('t0 0 s1');
			dis.arrowUpClr.transform('t0 0 s1');
			setTimeout(function() {
				if (dis.modMenu.onSum) return;
				dis.modMenu.hide();
			},0);		
		},
		null,null
	)
	this.arrowUpClr.click(
		function() {
			changeNum(dis,1);
		}
	)
	
	this.arrowDown = parent.polyline(x+94,y+285, x+98,y+287, x+102,y+285).attr({fill:'none',stroke:'black',strokeWidth:2});
	this.arrowDownClr = parent.rect(x+90,y+281,18,13).attr({opacity:0.0});
	this.arrowDownClr.hover(
		function() {
			dis.modMenu.onSum=true;
			for (var i=0; i<GS.chps.length; i++)
				if (GS.chps[i].rMenu.menuTog) return;
			dis.arrowDown.transform('t0 0 s1.2');
			dis.arrowDownClr.transform('t0 0 s1.2');
		},
		function() {
			dis.modMenu.onSum=false;			
			dis.arrowDown.transform('t0 0 s1');
			dis.arrowDownClr.transform('t0 0 s1');
			setTimeout(function() {
				if (dis.modMenu.onSum) return;
				dis.modMenu.hide();
			},0);			
		},
		null,null
	)	
	this.arrowDownClr.click(
		function() {
			changeNum(dis,-1);
		}
	)
	
	this.arrows = parent.group(this.arrowUp,this.arrowUpClr,this.arrowDown,this.arrowDownClr).attr({opacity:0,display:'none'});
	
	this.swbx = x;
	this.swBar = parent.rect(x+45,0,50,window.innerHeight).attr({opacity:0.0});
	this.swBar.hover(
		function(m) {
			for (var i=0; i<GS.chps.length; i++)
				GS.chps[i].swBar.attr({display:''});
			dis.swBar.attr({display:'none'});
			xSpace = dis.swbx-105;
			//if (m.movementX > 0)
			//	xSpace += 50;
			//if (m.movementX < 0)
			//	xSpace -= 50;
		},
		function(m) {
		
		},
		null,null
	)
	this.clr = parent.rect(x+50,y+247,40,43).attr({opacity:0.0});
	this.clr.hover(
		function() {
			if (KEYMENUOPEN) return;
			for (var i=0; i<GS.chps.length; i++)
				if (GS.chps[i].mtog) return;
			dis.modMenu.onSum=true;
			var txt = getData(dis.label);
			if (txt!=' ' && txt.indexOf('Gr')==-1 && txt.indexOf('Fr')==-1 && txt.indexOf('It')==-1)
				dis.modMenu.show();
			//dis.arrows.animate({opacity:1},300);
			for (var i=0; i<GS.hrects.length; i++) {
				if (GS.hrects[i].note) {
					GS.hrects[i].note.remove();
					GS.hrects[i].note=null;
				}
				if (GS.hrects[i].ledgers) {
					for (var j=0; j<GS.hrects[i].ledgers.length; j++)
						GS.hrects[i].ledgers[j].remove();
				}
			}
		},
		function() {
			dis.modMenu.onSum=false;
			setTimeout( function() {
				if (dis.modMenu.onSum) return;
				if (getData(dis.label)!=' ')
					dis.modMenu.hide();
			},500);
		},
		null,null
	)
	this.clr.click(
		function() {
			if (KEYMENUOPEN) return;
			if (dis.rMenu.sdtog) {
				var tm=0;
				for (var i=0; i<GS.chps.length; i++)
					if (GS.chps[i].mtog==true && GS.chps[i]!=dis) {
						GS.chps[i].rMenu.hide();
						GS.chps[i].mtog=false;
						dimRlabs(GS.chps[i],1);
						prnt.dimStaff(1);
						tm=1;
						break;
					}
				setTimeout(function() {				
					var roms = [dis.rMenu.nroms,dis.rMenu.Lroms][dis.rMenu.ltog*1];
					var sts = ['N','L'][dis.rMenu.ltog*1];
					switch(dis.mtog) {
						case false:
							setAry(dis.rMenu.romAry,roms);
							dis.rstate=sts;
							dis.rMenu.show();
							dimRlabs(dis,0);
							prnt.dimStaff(0);
							dis.mtog=true;
							break;
						case true:
							dis.rMenu.hide();
							if (dis.rstate!='SD') {
								dimRlabs(dis,1);
								prnt.dimStaff(1);
								dis.mtog=false;
								return;
							}
							setTimeout(function() {
								setAry(dis.rMenu.romAry,roms);
								dis.rstate=sts;
								dis.rMenu.show();
							},400);
							break;
					}
				},300*tm);
			}
			else {
				var tm=0;
				for (var i=0; i<GS.chps.length; i++)
					if (GS.chps[i].mtog==true) {
						GS.chps[i].rMenu.hide();
						GS.chps[i].mtog=false;
						dimRlabs(GS.chps[i],1);
						prnt.dimStaff(1);
						tm=1;
						break;
					}			
				setTimeout(function() {
					switch(dis.mtog) {
						case false:
							if (dis == GS.chps[i]) return;
							dis.rMenu.show();
							dimRlabs(dis,0);
							prnt.dimStaff(0);
							break;
						case true:
							dis.rMenu.hide();
							dimRlabs(dis,1);
							prnt.dimStaff(1);
							break;
					}
					dis.mtog=!dis.mtog;
				},300*tm);
			}
		}
	)
	this.sdlabel = parent.text(x+50,y+287,' ').attr({fontSize:'12px','font-family':'myFirstFont',display:'none'});
	this.centerSD = function() {
		var ww = 30;
		this.sdlabel.transform('t'+(ww-this.sdlabel.getBBox().width/2)+' 0');
	}
	this.sdClr = parent.rect(x+65,y+274.5,25,17.5).attr({opacity:0.0,display:'none'});
	this.sdClr.click(
		function() {
			var tm=0;
			for (var i=0; i<GS.chps.length; i++)
				if (GS.chps[i].mtog==true && GS.chps[i]!=dis) {
					GS.chps[i].rMenu.hide();
					GS.chps[i].mtog=false;
					dimRlabs(GS.chps[i],1);
					prnt.dimStaff(1);
					tm=1;
					break;
				}
			setTimeout(function() {			
				switch(dis.mtog) {
					case true:
						dis.rMenu.hide();
						if (dis.rstate=='SD') {
							dis.rMenu.hide();
							dimRlabs(dis,1);
							prnt.dimStaff(1);
							dis.mtog=false;
							return;
						}
						setTimeout(function() {
							setAry(dis.rMenu.romAry,dis.rMenu.sdroms);
							dis.rstate='SD';
							dis.rMenu.show();
						},400)
						break;
					case false:
						setAry(dis.rMenu.romAry,dis.rMenu.sdroms);
						dis.rstate='SD';
						dimRlabs(dis,0);
						prnt.dimStaff(0);
						dis.rMenu.show();
						dis.mtog=true;
						break;
				}
			},300*tm);
		}
	)
	this.sdline = parent.line(x+60,y+286,x+80,y+266).attr({stroke:'black',display:'none'});
	this.sdx2 = x+80;
	this.sdy2 = y+266;
	this.whole=parent.group(this.sdline,this.sdlabel,this.sdClr,this.line,this.label,this.modMenu.whole,this.clr,this.swBar,this.rMenu.whole,this.arrows);
}

function stripNum(num) {
	var nary=['\u01BE','\u01A2','\u01A3','\u01A4','\u01A0','\u01A1','\u01BB','\u01BC','\u01BD','\u01BE','\u01BF','\u01C0','\u01C1','\u01C2'];
	for (var i=0; i<nary.length; i++) {
		while(num.indexOf(nary[i])!=-1)
			num=num.replace(nary[i],'');
	}
	return num;
}

function changeNum(obj,dir) {
	var num;
	//if (obj.inv!='' && obj.inv!='\u01BE')
	//	num = getData(obj.label).split(obj.inv)[0];
	//else
		num = getData(obj.label);
	//else
	//	num = stripNum(getData(obj.label));
	var inv = obj.inv;
	var poss = findInv(num,dir,inv);
	var newInv = poss[poss.indexOf(inv)+Math.abs(dir)];
	
	//if seventh chord
	var sevs=['\u01BE','\u01A2','\u01A3','\u01A4'];
	var mod='';
	if (sevs.indexOf(obj.inv) != -1) {
		switch(obj.mod) {
			case '\u01BD':
				mod = '\u01BD';
				break;
			case '\u01C1':
				mod = '\u01C1';
				break;
			case '\u01C2':
				mod = '\u01C2';
			default:
				var nsv = num;
				for (var i=0; i<4; i++) {
					num = num.split(sevs[i]);
					if (num.length>1) {
						num = num[0];
						break;
					} else {
						num = nsv;
					}
				}
				break;
		}
	} else {
		switch(obj.mod) {
			case '\u01BD':
				mod='\u01BD';
				break;
			case '\u01BF':
				mod='\u01BF';
				break;
			case '\u01C1':
				mod='\u01C1';
				break;
		}
	}	
	var nary=['\u01BE','\u01A2','\u01A3','\u01A4','\u01A0','\u01A1','\u01BB','\u01BC','\u01BD','\u01BE','\u01BF','\u01C0','\u01C1','\u01C2'];
	for (var i=0; i<nary.length; i++)
		while(num.indexOf(nary[i])!=-1)
			num=num.replace(nary[i],'');
	setData(obj.label,num+mod+newInv);
	//obj.clb.note.lhLbl.whole.remove();
	//obj.clb.note.lhLbl=new locHarmLbl(obj.clb.note,num+mod+newInv,obj);
	obj.inv = newInv;
	obj.mod = mod;
	//obj.chrect.inversion = newInv;
	obj.centerLabel();
}

function findInv(num,dir,inv) {
	//var sinvs =['\u01A2','\u01A3','\u01A4'];
	//if (sinvs.indexOf(inv)!=-1) num+='\u01BE';
	
	var rns = ["I", "i", "ii", "N", "iii", "\u1D38", "III", "IV", "iv", "V", "v", "\u1D38", "\u1D38", "vi", "VI", "vii", "VII", '\u01BD', '\u01BF', '\u01C1','\u01C2'];
	for (var i=0; i<rns.length; i++) {
		while(num.indexOf(rns[i])!=-1)
			num=num.replace(rns[i],"");
	}
	var reg = ['','\u01BD','\u01BF','\u01A0','\u01A1'];
	var sev = ['\u01BB','\u01BC','\u01BE','\u01C0','\u01A2','\u01A3','\u01A4'];
	//var reg = ["I", "ii", "iii", "IV", "V", "vi", "vii\u01BD", "vii", "ii\u01BD", "iii\u01BD", "vi\u01BD", "i", "\u1D38II", "N", "\u1D38III", "iv", "v", "\u1D38VI", "\u1D38VII", "\u1D38III\u01BF"];
	//var sev = ["I\u01BE", "ii\u01BE", "iii\u01BE", "IV\u01BE", "V\u01BE", "vi\u01BE", "i\u01BE", "iv\u01BE", "v\u01BE", "vii\u01BE", "vii\u01BC", "ii\u01BC", "iii\u01BC", "vi\u01BC", "ii/o7", "iii/o7", "vi/o7", "vii/o7"];
	switch(dir) {
		case 1:
			//if (num=='N') return ['\u01A0','\u01A1','\u01A0'];
			if (reg.indexOf(num)!=-1) return ['','\u01A0','\u01A1',''];
			if (sev.indexOf(num)!=-1) return ['\u01BE','\u01A2','\u01A3','\u01A4','\u01BE'];
			break;
		case -1:
			//if (num=='N') return ['\u01A1','\u01A0','\u01A1'];
			if (reg.indexOf(num)!=-1) return ['','\u01A1','\u01A0',''];
			if (sev.indexOf(num)!=-1) return ['\u01BE','\u01A4','\u01A3','\u01A2','\u01BE'];
			break;
	}
}

function getData(thing) {
    return thing.node.childNodes[0].data;
}

function setData(thing,data) {
    thing.node.childNodes[0].data=data;
}

function getProgression() {
	var prog=[];
	var obj;
	for (var i=0; i<GS.chps.length; i++) {
		obj={};
		obj.chord=stripNum(getData(GS.chps[i].label));
		obj.inv=GS.chps[i].inv;
		obj.mod=GS.chps[i].mod;
		if (getData(GS.chps[i].sdlabel)!=" ")
			obj.sd=getData(GS.chps[i].sdlabel);
		prog.push(obj);
	}
	return prog;
}

var RMENUOPEN=false;
function rMenu(x,y,type,parent) {
    this.parent=parent;
    var stf = this.parent.parent;
    this.romAry=[];
    //this.key="F";
	//var key;
	//Object.defineProperty(this, "key", {
	//	get: function() { return key; },
	//	set: function(k) {
	//	    key=k;
	//		setSig(k,this);
	//	}
	//});
	//this.key="F";
	
    //this.notes=[];
    var dis=this;
	var roms;
	//this.nroms= ["V","vi","It\u207A\u2076","Gr\u207A\u2076","Fr\u207A\u2076","vii\u00B0","I","ii","iii","IV"];
	this.nroms= ["V","vi","It\u01BA","Gr\u01BA","Fr\u01BA","vii\u01BD","I","ii","iii","IV"];
	this.Lroms = ["v","\u1D38VI","It\u01BA","Gr\u01BA","Fr\u01BA","\u1D38VII","i","N\u01A0","\u1D38III","iv"];	
	//this.Lroms = ["v","\u1D38VI","It\u207A\u2076","Gr\u207A\u2076","Fr\u207A\u2076","\u1D38VII","i","N\u2076","\u1D38III","iv"];
	this.sdroms = ["\u1D38VII","ii","iii","iv","IV","V","vi","\u1D38II","\u1D38III","\u1D38VI"];
	//var keys = ["B","F♯","D♭","A♭","E♭","B♭","F","C","G","D","A","E"];
	//var Lkeys = ["bm","f♯m","c♯m","g♯m","e♭m","b♭m","fm","cm","gm","dm","am","em"];

	switch(type) {
	    case 0:
	        roms=this.nroms;
	        break;
	    case 1:
	        roms=this.Lroms;
	        break;
	    //case 2:
	    //    roms=keys;
	    //    break;
	    //case 3:
	    //    roms=Lkeys;
	    //    break;
	    default:
	        roms=this.nroms;
	        break;
	}
	//var relations=[];
	this.lback=stf.rect(5,130,30,15,5).attr({fill:"#FFFFFF",stroke:"#989898"});
	this.lbutton=stf.rect(5,130,15,15,5).attr({fill:'#E7E7E7',stroke:"#989898"});
	this.ltxt=stf.text(24.5,143,"\u1D38").attr({fill:'black','font-size':'14px'});
	//this.mtxt=S.text(22.5,142,"m").attr({fill:'black','font-size':'12px',display:"none"});
	
	this.lclr=stf.rect(5,130,30,15,5).attr({opacity:'0.0'});
	this.lgroup = stf.group(this.lback,this.lbutton,this.ltxt,this.lclr).attr({display:'none'});
	this.ltog=false;
	this.lclr.click(
	    function() {
	        if (dis.menuTog==true) {
                dis.ltog=!dis.ltog;
                switch(dis.ltog) {
                    case true:
                        dis.lbutton.animate({transform:'t15 0'},100);
                        //dis.hide();
                        //setTimeout(function() {
                            //switch(dis.parent.mode) {
                                //case "PIV":
                                //    if (dis.parent.pivot.select=="key")
                                //        setAry(dis.romAry,Lkeys);
                                //    else
                                //        setAry(dis.romAry,Lroms);
                                //    break;
                                //case "RN":
                                    setAry(dis.romAry,dis.Lroms);
                                    dis.parent.rstate='L';
                            //        break;
                            //}
                           // dis.show();
                        //},400)
                        break;
                    case false:
                        dis.lbutton.animate({transform:'t0 0'},100);
                        //dis.hide();
                        //setTimeout(function() {
                        //    switch(dis.parent.mode) {
                        //        case "PIV":
                        //            if (dis.parent.pivot.select=="key")
                        //                setAry(dis.romAry,keys);
                        //            else
                                        setAry(dis.romAry,dis.nroms);
                                        dis.parent.rstate='N';
                        //            break;
                        //        case "RN":
                        //            setAry(dis.romAry,nroms);
                        //            break;
                        //    }
                        //    dis.show();
                        //},400)
                        break;
                }
	        } else {
	            dis.ltog=!dis.ltog;
	            switch(dis.ltog) {
	                case true:
	                    dis.lbutton.animate({transform:'t15 0'},100);
                        //switch(dis.parent.mode) {
                        //    case "PIV":
                        //        if (dis.parent.pivot.select=="key")
                        //            setAry(dis.romAry,Lkeys);
                        //        else
                        //            setAry(dis.romAry,Lroms);
                        //        break;
                        //    case "RN":
                                setAry(dis.romAry,dis.Lroms);
                                dis.parent.rstate='L';
                        //        break;
                        //}
	                    dis.show();
	                    break;
	                case false:
	                    dis.lbutton.animate({transform:'t0 0'},100);
                        //switch(dis.parent.mode) {
                        //    case "PIV":
                        //        if (dis.parent.pivot.select=="key")
                        //            setAry(dis.romAry,keys);
                        //        else
                        //            setAry(dis.romAry,nroms);
                        //        break;
                        //    case "RN":
                                setAry(dis.romAry,dis.nroms);
                                dis.parent.rstate='N';
                        //        break;
                        //}
	                    dis.show();
	                    break;
	            }
	        }
	    }
	)
	
	//secondary dominant
	var plux = 74;
	this.sdback=stf.rect(plux+5,130,30,15,5).attr({fill:"#FFFFFF",stroke:"#989898"});
	this.sdbutton=stf.rect(plux+5,130,15,15,5).attr({fill:'#E7E7E7',stroke:"#989898"});
	this.sdtxt=stf.text(plux+24.5,143,"/").attr({fill:'black','font-size':'14px',fontWeight:'bold'});
	//this.mtxt=S.text(22.5,142,"m").attr({fill:'black','font-size':'12px',display:"none"});
	
	this.sdclr=stf.rect(plux+5,130,30,15,5).attr({opacity:'0.0'});
	this.sdgroup = stf.group(this.sdback,this.sdbutton,this.sdtxt,this.sdclr).attr({display:'none'});
	this.sdtog=false;
	this.sdclr.click(
	    function() {
	        if (dis.menuTog==true) {
                dis.sdtog=!dis.sdtog;
                switch(dis.sdtog) {
                    case true:
                        dis.sdbutton.animate({transform:'t15 0'},100);
                        changeSD(dis.parent,1);
                        //dis.hide();
                        //setTimeout(function() {
                            //switch(dis.parent.mode) {
                                //case "PIV":
                                //    if (dis.parent.pivot.select=="key")
                                //        setAry(dis.romAry,Lkeys);
                                //    else
                                //        setAry(dis.romAry,Lroms);
                                //    break;
                                //case "RN":
                          //          setAry(dis.romAry,Lroms);
                            //        break;
                            //}
                            //dis.show();
                        //},400)
                        break;
                    case false:
                        dis.sdbutton.animate({transform:'t0 0'},100);
                        //for (var i=0; i<GS.chps.length; i++) {
						//	dimRlabs(GS.chps[i],1);
							//GS.dimStaff(1);
						//}
						//dis.parent.mtog=false;
                        //dis.hide();
                        var roms = [dis.nroms,dis.Lroms][dis.ltog*1];
                        var sts = ['N','L'][dis.ltog*1];
                        //setTimeout(function() {
							setAry(dis.romAry,roms);
							dis.parent.rstate=sts;
						//}
						//,400)
                        changeSD(dis.parent,0);
                        //dis.hide();
                        //setTimeout(function() {
                        //    switch(dis.parent.mode) {
                        //        case "PIV":
                        //            if (dis.parent.pivot.select=="key")
                        //                setAry(dis.romAry,keys);
                        //            else
                        //                setAry(dis.romAry,nroms);
                        //            break;
                        //        case "RN":
                        //            setAry(dis.romAry,nroms);
                        //            break;
                        //    }
                        //    dis.show();
                        //},400)
                        break;
                }
	        } else {
	            dis.ltog=!dis.ltog;
	            switch(dis.ltog) {
	                case true:
	                    dis.sdbutton.animate({transform:'t15 0'},100);
                        //switch(dis.parent.mode) {
                        //    case "PIV":
                        //        if (dis.parent.pivot.select=="key")
                        //            setAry(dis.romAry,Lkeys);
                        //        else
                        //            setAry(dis.romAry,Lroms);
                        //        break;
                        //    case "RN":
                        //        setAry(dis.romAry,Lroms);
                        //        break;
                        //}
	                    //dis.show();
	                    break;
	                case false:
	                    dis.sdbutton.animate({transform:'t0 0'},100);
                        //switch(dis.parent.mode) {
                        //    case "PIV":
                        //        if (dis.parent.pivot.select=="key")
                        //            setAry(dis.romAry,keys);
                        //        else
                        //            setAry(dis.romAry,nroms);
                        //        break;
                        //    case "RN":
                        //        setAry(dis.romAry,nroms);
                        //        break;
                        //}
	                    //dis.show();
	                    break;
	            }
	        }
	    }
	)	

    this.hideStaff = function() {
        if (this.notes[0]) {
            for (var i=0; i<this.notes.length; i++) {
                if (this.notes[i].flat) this.notes[i].flat.remove();
                if (this.notes[i].sharp) this.notes[i].sharp.remove();
                if (this.notes[i].natural) this.notes[i].natural.remove();
                if (this.notes[i].doubleflat) this.notes[i].doubleflat.remove();
                if (this.notes[i].doublesharp) this.notes[i].doublesharp.remove();

                if (this.notes[i].ledger) this.notes[i].ledger.remove();
                this.notes[i].remove();
            }
        }
        this.parent.staff.attr({display:"none"});
        if (this.flats) {
            for (var i=0; i<this.flats.length; i++)
                this.flats[i].remove();
        }
        if (this.sharps) {
            for (var i=0; i<this.sharps.length; i++)
                this.sharps[i].remove();
        }
    }

    this.showStaff = function() {
        this.parent.staff.attr({display:""});
    }  

    this.scale=[];
    /*this.drawScale = function() {
        //var notes=["Bff","B♭","B","B♯","Bx","Cff","C♭","C","C♯","Cx","Dff","D♭","D","D♯","Dx","Eff","E♭","E","E♯","Ex","Fff","F♭","F","F♯","Fx","Gff","G♭","G","G♯","Gx","Aff","A♭","A","A♯","Ax"];

        var scale=scaleMaker(dis.key);
        var pos=[90,85,80,75,70,65,60,55];
        //var pos=  [110, 110, 110,  110, 110,  105, 105, 105, 105, 105,   100, 100,  100, 100, 100,  95,  95,  95, 95, 95,     90,   90,  90, 90, 90,      85,  85,  85, 85, 85,      80,  80,  80, 80, 80];

        //One octave up
        //var ups=  [75, 75, 75 ,   75,  75,  70, 70, 70,  70,  70,  65, 65, 65,  65,   65,  60,60,60,  60,  60,  55,55,55,   55,  55,   50,50,50,  50,  50,  45,45,45,  45,  45];

        var ary=[];
        for (var i=0; i<scale.length; i++) {
        //    if ((i>0)&&(pos[notes.indexOf(scale[i])]>pos[notes.indexOf(scale[i-1])]))
        //        ary=ups;
        //    else
        ary=pos;
            this.scale[i]=S.path(wholePath).attr({fill:"black"}).transform("t" + (-37+15*i) + " " + (ary[i]) + " s0.03 -0.034");
        //Make da ledger
            if (ary[i]>100) {
            this.scale[i].ledger=S.line(216,105,241,105).attr({stroke:"black"});
            }
        }
    }*/

	this.drawChord = function(tog) {

        var notes=["Bff","B♭","B","B♯","Bx","Cff","C♭","C","C♯","Cx","Dff","D♭","D","D♯","Dx","Eff","E♭","E","E♯","Ex","Fff","F♭","F","F♯","Fx","Gff","G♭","G","G♯","Gx","Aff","A♭","A","A♯","Ax"];
        var invs=["\u0162","\u0164","\u0163","\u00B0\u0162","\u00B0\u0164","\u00B0\u0163"];
        var augs=["Gr⁺⁶","Fr⁺⁶","It⁺⁶"];
        //var invs1=["⁷","⁶","⁶₄"];

        //Base positions
        var pos=  [110, 110, 110,  110, 110,  105, 105, 105, 105, 105,   100, 100,  100, 100, 100,  95,  95,  95, 95, 95,     90,   90,  90, 90, 90,      85,  85,  85, 85, 85,      80,  80,  80, 80, 80];

        //One octave up
        var ups=  [75, 75, 75 ,   75,  75,  70, 70, 70,  70,  70,  65, 65, 65,  65,   65,  60,60,60,  60,  60,  55,55,55,   55,  55,   50,50,50,  50,  50,  45,45,45,  45,  45];

        //find dat ho
        //var toggo=tog||2;
        var toggo = (tog!=undefined) ? tog : 2;
        var chord;
        switch(toggo) {
            case 0:
                chord=findChord("I",dis.parent.rNum.mod,dis.parent.rNum.inv,dis.key);
                break;
            case 1:
                chord=findChord("I",dis.parent.rNum.mod,dis.parent.rNum.inv,dis.key);
                break;
            case 2:
                chord=findChord(dis.parent.rNum.base,dis.parent.rNum.mod,dis.parent.rNum.inv,dis.key);
                break;
        }
        //var chord=findChord(dis.parent.rNum.base,dis.parent.rNum.mod,dis.parent.rNum.inv,dis.key);

        //get dat key sig
        var sig=keySig(dis.key);

        //Are we in a sharp or flat key?
        var fs="none";
        var scale=scaleMaker(dis.key);
        for (var i=0; i<scale.length; i++) {
            if (scale[i].indexOf("♯")!=-1) fs="sharp";
            if (scale[i].indexOf("♭")!=-1) fs="flat";
        }

        //Move da bitches over when keys get big
        var keyspace=0;
        if (["A","E","B","F♯","C♯"].indexOf(dis.key)!=-1) keyspace=(1+["A","E","B","F♯","C♯"].indexOf(dis.key))*8;
        if (["E♭","A♭","D♭","G♭","C♭"].indexOf(dis.key)!=-1) keyspace=(1+["E♭","A♭","D♭","G♭","C♭"].indexOf(dis.key))*8;

        //Ensure proper visual stacking and set up the play array
        var prepAry=[];
        var the3s=["B♭","B","C♭"];
        for (var i=0; i<chord.length; i++) {
            if (the3s.indexOf(chord[i])!=-1)
                prepAry[i]=fixNote(chord[i])+"3";
            else
                prepAry[i]=fixNote(chord[i])+"4";
        }

        for (var i=1; i<chord.length; i++) {
            if (pos[notes.indexOf(chord[i])]>pos[notes.indexOf(chord[i-1])]) {
                pos[notes.indexOf(chord[i])]-=35;
                var val=prepAry[i];
                switch(val[val.length-1]) {
                    case "3":
                        prepAry[i]=fixNote(chord[i])+"4";
                        break;
                    case "4":
                        prepAry[i]=fixNote(chord[i])+"5";
                        break;
                    case "5":
                        prepAry[i]=fixNote(chord[i])+"6";
                        break;
                }
            }
        }
        //var playAry = fixAry(prepAry);

        //Remove previous accidentals and ledgers
        if (this.notes[0]) {
            for (var i=0; i<this.notes.length; i++) {
                if (this.notes[i].flat) this.notes[i].flat.remove();
                if (this.notes[i].sharp) this.notes[i].sharp.remove();
                if (this.notes[i].natural) this.notes[i].natural.remove();
                if (this.notes[i].doubleflat) this.notes[i].doubleflat.remove();
                if (this.notes[i].doublesharp) this.notes[i].doublesharp.remove();

                if (this.notes[i].ledger) this.notes[i].ledger.remove();
                this.notes[i].remove();
                if (this.fivethree[0]) {
                    if (this.fivethree[i].ledger) this.fivethree[i].ledger.remove();
                    if (this.fivethree[i].tline) this.fivethree[i].tline.remove();
                    this.fivethree[i].remove();
                }
            }
        }

        //Add/Subtract room for accidentals
        var axspace=-15;
        for (var i=0; i<chord.length; i++) {
            if (fs=="flat") {
                if (((chord[i].indexOf("♭")!=-1))&&(sig.indexOf(chord[i])==-1)) axspace=0;
            }
            if (fs=="sharp") {
                if (((chord[i].indexOf("♯")!=-1))&&(sig.indexOf(chord[i])==-1)) axspace=0;
            }
            if (fs=="none") {
                if (((chord[i].indexOf("♭")!=-1))&&(sig.indexOf(chord[i])==-1)) axspace=0;
                if (((chord[i].indexOf("♯")!=-1))&&(sig.indexOf(chord[i])==-1)) axspace=0;
            }
            for (var j=0; j<sig.length; j++) {
                if (fs=="sharp") {
                    if (chord[i].indexOf("♭")!=-1) axspace=0;
                    if ((chord[i].indexOf("♯")==-1)&&(pos[notes.indexOf(chord[i])]==pos[notes.indexOf(sig[j])])) axspace=0;
                    if ((chord[i].indexOf("♯")==-1)&&(pos[notes.indexOf(chord[i])]==pos[notes.indexOf(sig[j])]-35)) axspace=0;
                }
                if (fs=="flat") {
                    if (chord[i].indexOf("♯")!=-1) axspace=0;
                    if ((chord[i].indexOf("♭")==-1)&&(pos[notes.indexOf(chord[i])]==pos[notes.indexOf(sig[j])])) axspace=0;
                    if ((chord[i].indexOf("♭")==-1)&&(pos[notes.indexOf(chord[i])]==pos[notes.indexOf(sig[j])]-35)) axspace=0;
                }
            }
        }

        //Draw the notes
        this.fivethree=[];
        var ftchord=findChord("V","","",dis.key);
        var ft=[0,5,5];
        this.notes=[];
        for (var i=0; i<chord.length; i++) {
            this.notes[i]=S.path(wholePath).attr({fill:"black"}).transform("t" + (-19+keyspace+axspace) + " " + (pos[notes.indexOf(chord[i])]) + " s0.034 -0.034");
            if (tog!=undefined) {
                //var ft=0;
                //if (i==2) ft=-35;
                this.fivethree[i]=S.path(wholePath).attr({fill:"black"}).transform("t"+(10+keyspace+axspace)+" "+(pos[notes.indexOf(chord[i])]+ft[i]) + " s0.034 -0.034");
                if (i>0) {
                    var w=this.notes[0].node.getBoundingClientRect().width;
                    this.fivethree[i].tline=S.line(222+keyspace+axspace+w,pos[notes.indexOf(chord[i])]+1,230+keyspace+axspace+w,pos[notes.indexOf(chord[i])]+ft[i]-2).attr({stroke:"black",strokeWidth:"2"});
                }
            }
            //Make da ledger
            if (pos[notes.indexOf(chord[i])]>100) {
                this.notes[i].ledger=S.line(216+keyspace+axspace,105,241+keyspace+axspace,105).attr({stroke:"black"});
                if (tog!=undefined)
                    this.fivethree[i].ledger=S.line(245+keyspace+axspace,105,270+keyspace+axspace,105).attr({stroke:"black"});
            }

            //Accidentals
            //Add flats if they aren't in the key signature
            if (fs=="flat") {
                if (chord[i].indexOf("♯")!=-1)
                    this.notes[i].sharp=S.path(sharpPath).attr({fill:"black"}).transform('t' + (76+keyspace+axspace) + ' ' + (pos[notes.indexOf(chord[i])]) + " s0.034 -0.034");
                if ((chord[i].indexOf("♭")!=-1)&&(sig.indexOf(chord[i])==-1)) {
                    this.notes[i].flat=S.path(flatPath).attr({fill:"black"}).transform('t' + (126+keyspace+axspace) + ' ' + (pos[notes.indexOf(chord[i])]-156) + " s0.034 -0.034");
                }
            }

            //Add sharps if they aren't in the key signature
            if (fs=="sharp") {
                if (chord[i].indexOf("♭")!=-1)
                    this.notes[i].flat=S.path(flatPath).attr({fill:"black"}).transform('t' + (126+keyspace+axspace) + ' ' + (pos[notes.indexOf(chord[i])]-156) + " s0.034 -0.034");
                if ((chord[i].indexOf("♯")!=-1)&&(sig.indexOf(chord[i])==-1)) {
                    this.notes[i].sharp=S.path(sharpPath).attr({fill:"black"}).transform('t' + (76+keyspace+axspace) + ' ' + (pos[notes.indexOf(chord[i])]) + " s0.034 -0.034");
                }
            }

            if (fs=="none") {
               if (chord[i].indexOf("♭")!=-1)
                    this.notes[i].flat=S.path(flatPath).attr({fill:"black"}).transform('t' + (126+keyspace+axspace) + ' ' + (pos[notes.indexOf(chord[i])]-156) + " s0.034 -0.034");
               if ((chord[i].indexOf("♯")!=-1)&&(sig.indexOf(chord[i])==-1)) {
                    this.notes[i].sharp=S.path(sharpPath).attr({fill:"black"}).transform('t' + (76+keyspace+axspace) + ' ' + (pos[notes.indexOf(chord[i])]) + " s0.034 -0.034");
               }
            }

            //Do da fuggin double sharps
            if (chord[i].indexOf("x")!=-1) {
                this.notes[i].doublesharp=S.path(doublesharpPath).attr({fill:"black"}).transform('t' + (176+keyspace+axspace) + ' ' + (pos[notes.indexOf(chord[i])]-307) + " s0.2");
            }

            //Do da fuggin double flats
            if (chord[i].indexOf("ff")!=-1) {
                this.notes[i].doubleflat=S.path(doubleflatPath).attr({fill:"black"}).transform('t' + (134+keyspace+axspace) + ' ' + (pos[notes.indexOf(chord[i])]-335) + " s0.17");
            }

            //If the notes aren't sharp or flat, and they appear on a key sig line, add a natural
            for (var j=0; j<sig.length; j++) {
                if (fs=="sharp") {
                    if (chord[i].indexOf("x")==-1) {
                        if ((chord[i].indexOf("♯")==-1)&&(pos[notes.indexOf(chord[i])]==pos[notes.indexOf(sig[j])])) {
                            this.notes[i].natural=S.path(naturalPath).attr({fill:"black"}).transform('t' + (128+keyspace+axspace) + ' ' + (pos[notes.indexOf(chord[i])]) + " s0.034 -0.034");
                        }
                        if ((chord[i].indexOf("♯")==-1)&&(pos[notes.indexOf(chord[i])]==pos[notes.indexOf(sig[j])]-35)) {
                            this.notes[i].natural=S.path(naturalPath).attr({fill:"black"}).transform('t' + (128+keyspace+axspace) + ' ' + (pos[notes.indexOf(chord[i])]) + " s0.034 -0.034");
                        }
                    }
                }
                if (fs=="flat") {
                    if (chord[i].indexOf("ff")==-1) {
                        if ((chord[i].indexOf("♭")==-1)&&(pos[notes.indexOf(chord[i])]==pos[notes.indexOf(sig[j])])) {
                            this.notes[i].natural=S.path(naturalPath).attr({fill:"black"}).transform('t' + (128+keyspace+axspace) + ' ' + (pos[notes.indexOf(chord[i])]) + " s0.034 -0.034");
                        }
                        if ((chord[i].indexOf("♭")==-1)&&(pos[notes.indexOf(chord[i])]==pos[notes.indexOf(sig[j])]-35)) {
                            this.notes[i].natural=S.path(naturalPath).attr({fill:"black"}).transform('t' + (128+keyspace+axspace) + ' ' + (pos[notes.indexOf(chord[i])]) + " s0.034 -0.034");
                        }
                    }
                }
            }

            //Spacing
            if ((invs.indexOf(this.parent.rNum.inv)!=-1)&&(chord[i]==findRoot(dis.parent.rNum.base,dis.key))) {
                this.notes[i].transform('t' + (-5+keyspace+axspace) + ' ' + pos[notes.indexOf(chord[i])] + " s0.034 -0.034");
            }
        }

        //Dem augs
        if (augs.indexOf(this.parent.rNum.base)!=-1) {
            switch(this.parent.rNum.base) {
                case "Gr⁺⁶":
                    this.notes[3].transform('t' + (-5+keyspace+axspace) + ' ' + pos[notes.indexOf(chord[3])] + " s0.034 -0.034");
                    if (this.notes[2].flat) this.notes[2].flat.transform('t' + (116+keyspace+axspace) + ' ' + (pos[notes.indexOf(chord[2])]-156) + " s0.034 -0.034");
                    if (this.notes[2].natural) this.notes[2].natural.transform('t' + (118+keyspace+axspace) + ' ' + pos[notes.indexOf(chord[2])] + " s0.034 -0.034");
                    if (this.notes[0].doubleflat) this.notes[0].doubleflat.transform('t' + (126+keyspace+axspace) + ' ' + (pos[notes.indexOf(chord[0])]-335) + " s0.17");
                    if (this.notes[2].doubleflat) {
                        this.notes[2].doubleflat.transform('t' + (126+keyspace+axspace) + ' ' + (pos[notes.indexOf(chord[2])]-335) + " s0.17");
                        if (this.notes[3].natural) this.notes[3].natural.transform('t' + (131+keyspace+axspace) + ' ' + pos[notes.indexOf(chord[3])] + " s0.034 -0.034");
                    }
                    break;
                case "Fr⁺⁶":
                    this.notes[2].transform('t' + (-5+keyspace+axspace) + ' ' + pos[notes.indexOf(chord[2])] + " s0.034 -0.034");
                    break;
            }
        }

        //play the notes
        //for (var i=0; i<prepAry.length; i++) {
        //    playAudioNotes([theNotes.indexOf(prepAry[i])],true);
        //}

        //put dem awn
        for (var i=0; i<this.notes.length; i++) {
            this.whole.append(this.notes[i]);
            if (this.notes[i].sharp) this.whole.append(this.notes[i].sharp);
            if (this.notes[i].flat) this.whole.append(this.notes[i].flat);
            if (this.notes[i].natural) this.whole.append(this.notes[i].natural);
            if (this.notes[i].doubleflat) this.whole.append(this.notes[i].doubleflat);
            if (this.notes[i].doublesharp) this.whole.append(this.notes[i].doublesharp);
            if (this.notes[i].ledger) this.whole.append(this.notes[i].ledger);
        }
	}

    this.menuTog=false;
    for (var i=0; i<roms.length; i++) {
        this.romAry[i]=stf.text(52,78,roms[i]).attr({fill:'#000000','font-size':'14px',opacity:'0.0',fontFamily:'myFirstFont'});
        this.romAry[i].rect=stf.rect(49,63,this.romAry[i].getBBox().width+6,20,5).attr({opacity:'0.0',display:"none"});
        this.romAry[i].attr({display:"none"});
        this.romAry[i].rect.rom=this.romAry[i];
        stf.group(this.romAry[i],this.romAry[i].rect);
        this.romAry[i].rect.hover(
            function(m) {

                var sm=Snap(m.target);
                    //dis.hoverX=sm.matrix.e;
                    //dis.hoverY=sm.matrix.f;
                sm.animate({transform:'t'+sm.rom.x+' '+sm.rom.y+' s1.4'},55);
                sm.rom.animate({transform:'t'+sm.rom.x+' '+sm.rom.y+' s1.4'},55);

            },
            function(m) {
                var sm=Snap(m.target);
                //var tx=sm.matrix.e;
                //var ty=sm.matrix.f;
                sm.animate({transform:'t'+sm.rom.x+' '+sm.rom.y+' s1'},45);
                sm.rom.animate({transform:'t'+sm.rom.x+' '+sm.rom.y+' s1'},45);
            },
            null,null
        )        
        /*this.romAry[i].rect.hover(
        	function(m) {
        		var sm = Snap(m.target);
        		sm.rom.attr({"fill":"#FFFFFF"});
        	},
        	function(m) {
        		var sm = Snap(m.target);
        		sm.rom.attr({"fill":"#000000"});
        	},
        null, null);*/
        this.romAry[i].rect.click(
            function(m) {
				if (dis.parent.label.node.childNodes[0].data==Snap(m.target).rom.node.childNodes[0].data) {
					var sk=0;
					if (!dis.parent.rstate=='SD') {
						setData(dis.parent.label," ");
						dis.parent.centerLabel();
					} else {
						sk=1;
					}
					dis.hide();
					//dis.parent.arrows.attr({display:'none',opacity:0});
					dis.parent.mtog=false;
					GS.dimStaff(1);
					dimRlabs(dis.parent,1);
					if (sk==0)
						return;
				}
				
				if (getData(dis.parent.sdlabel)==getData(Snap(m.target).rom)) {
					var sk=0;
					if (dis.parent.rstate=='SD') {
						setData(dis.parent.sdlabel," ");
						dis.parent.centerSD();
					} else {
						sk=1;
					}
					dis.hide();
					dis.parent.mtog=false;
					GS.dimStaff(1);
					dimRlabs(dis.parent,1);
					if (sk==0)
						return;
				}
				
				if (dis.parent.rstate=='SD') {
					setData(dis.parent.sdlabel,getData(Snap(m.target).rom));
					dis.parent.centerSD();
					dis.hide();
					dis.parent.mtog=false;
					GS.dimStaff(1);
					dimRlabs(dis.parent,1);
					return;
				}
				else {
					setData(dis.parent.label,getData(Snap(m.target).rom));
					dis.parent.centerLabel();
				}
				//dis.parent.label.node.childNodes[0].data=Snap(m.target).rom.node.childNodes[0].data;
				dis.parent.inv='';
				if (Snap(m.target).rom.node.childNodes[0].data=='N\u2076')
					dis.parent.inv='\u2076';
				dis.parent.centerLabel();
				dis.hide();
				var txt = Snap(m.target).rom.node.childNodes[0].data;
				//if (txt.indexOf('Fr')==-1 && txt.indexOf('Gr')==-1 && txt.indexOf('It')==-1)
				//	dis.parent.arrows.attr({display:'',opacity:1});
				dis.parent.mtog=false;
				GS.dimStaff(1);
				dimRlabs(dis.parent,1);
        })
    }
    this.pass=1;
    this.show = function() {
		for (var z=0; z<GS.chps.length; z++)
			GS.chps[z].modMenu.hide();		
		RMENUOPEN=true;
        this.menuTog=true;
        this.parent.modMenu.hide();
        this.parent.arrows.attr({opacity:0.2});
        //this.parent.rNum.num.attr({transform:'t0 0 s1'});
        //this.parent.rNum.numclr.attr({transform:'t0 0 s1'});
        if (this.parent.rstate!='SD')
			this.lgroup.attr({display:''});
        this.sdgroup.attr({display:''});
        var alpha=0;
        var radius=44;
        var incr=(360/this.romAry.length)*(3.14159/180);
        var newX, newY;
        var adds, nadds, badds;
        for (var i=0; i<this.romAry.length; i++) {
            adds=0;
            nadds=0;
            badds=0;
            if (type<2) {
                if (roms[i][0]=="G") {adds=-9; this.romAry[i].rect.attr({width:35});}
                if (roms[i][0]=="I") nadds=-2;
                if (roms[i][0]=="F") badds=-6;
            }
            newX = radius*Math.cos(-i*incr);
            newY = radius*Math.sin(i*incr);
            this.romAry[i].attr({display:""});
            this.romAry[i].animate({transform:'t ' + (newX+adds+nadds+badds) + ' ' + (newY)},350,mina.backout);
            this.romAry[i].animate({opacity:'1.0'},250);
            this.romAry[i].rect.attr({display:""});
            dis.romAry[i].rect.attr({'width':dis.romAry[i].getBBox().width+6});
            this.romAry[i].rect.attr({transform:'t ' + (newX+adds+nadds+badds) + ' ' + (newY)});
            if (dis.pass==1) {
                dis.romAry[i].rect.rom.x=newX+adds+nadds+badds;
                dis.romAry[i].rect.rom.y=newY;
            }            
        }
        this.pass=2;
    };
    this.hide = function() {
		RMENUOPEN=false;
		this.menuTog=false;
        //this.parent.arrows.attr({opacity:1});
        this.lgroup.attr({display:'none'});
        this.sdgroup.attr({display:'none'});
        //this.parent.rNum.num.attr({transform:'t0 0 s3'});
        //this.parent.rNum.numclr.attr({transform:'t0 0 s3'});
        //dis.numeralCopen=!dis.numeralCopen;
        for (var i=0; i<this.romAry.length; i++) {
            this.romAry[i].animate({transform:'t0 0'},300,mina.backin);
            this.romAry[i].animate({opacity:'0.0'},350);
        }
        setTimeout(function() {
            for (var i=0; i<dis.romAry.length; i++) {
                dis.romAry[i].attr({display:'none'}); dis.romAry[i].rect.attr({display:"none"});
			}
			if (getData(dis.parent.label)!=" ") {
				dis.parent.modMenu.show();
				this.parent.modMenu.onSum=true;
			}
            //dis.whole.append(dis.numeralC);
        },225);
    }
    //this.whole=S.group(this.romAry[0],this.romAry[0].rect,this.lback,this.lbutton,this.ltxt,this.mtxt,this.lclr);
    this.whole=stf.group();
    for (var i=0; i<this.romAry.length; i++) {
        this.whole.append(this.romAry[i]);
        this.whole.append(this.romAry[i].rect);
    }
    this.whole.append(this.lgroup);
    this.whole.append(this.sdgroup);
    this.x = x; this.y = y;
    this.whole.transform('t'+x+' '+y);
    //this.show();
    //this.key=findKey(parent.chRect.index);
	//this.key="A";
}

function setAry(ary,data) {
	for (var i=0; i<ary.length; i++)
		ary[i].node.childNodes[0].data=data[i];
}

function dec2Bin(dec)
{
    if(dec >= 0) {
        return dec.toString(2);
    }
    else {
        /* Here you could represent the number in 2s compliment but this is not what
           JS uses as its not sure how many bits are in your number range. There are
           some suggestions http://stackoverflow.com/questions/10936600/javascript-decimal-to-binary-64-bit
        */
        return (~dec).toString(2);
    }
}

function getProgressionChords() {
	var progChords = [];
	var key = getData(GS.keyMenu.key);
	for (var i=0; i<GS.chps.length; i++) {
		progChords.push(findChord(getData(GS.chps[i].label).split(GS.chps[i].inv)[0],'',GS.chps[i].inv,key));
	}
	return progChords;
}

function fixRN(RN,MOD,INV) {
	return stripNum(RN);
	/*var mnd=RN.indexOf(MOD);
	var ind=RN.indexOf(INV);
	if (MOD!="" && MOD!=undefined)
		var rn = RN.slice(0,mnd);
	else {
		if (INV!="")
			var rn = RN.slice(0,ind);
		else
			var rn = RN;
	}
	return rn;*/
}

function findChord(RN,MOD,INV,KEY) {
//returns scale degree of root and the type of chord
	var rn = fixRN(RN,MOD,INV);
    var root=findRoot(rn,KEY);
    var type=findType(rn,MOD,INV);
    var inversion=INV;
    return chordBuild(root,type,inversion);


/*
    var type;
    if (["I","\u1D38II","\u1D38III","IV","V","\u1D38VI","\u1D38VII"].indexOf(RN)!=-1) {
        type="MAJ";
    }
    if (["i","ii","iii","iv","v","vi"].indexOf(RN)!=-1) {
        type="min";
    }
    if (MOD.indexOf("\u01BD")!=-1) {
        type="dim";
    }
    if ((MOD.indexOf("\u01BD")!=-1)&&(MOD.indexOf("\u01BE")!=-1)) {
        type="dim7";
    }
    if (MOD.indexOf("\u01BF")!=-1) {
        type="aug";
    }

    var scale=scaleMaker(KEY);
    var root=scale[roots.indexOf(RN)];

    return chordBuild(root,type);
*/
}

function findType(RN,MOD,INV) {
    var MAJORS=["I","N","\u1D38III","IV","\u1D38VI","\u1D38VII"];
    var minors=["i","ii","iii","iv","v","vi","vii"];
    var AUG6=["Gr\u01BA","Fr\u01BA","It\u01BA"];
    var type;
    switch(MOD) {
        case "\u01BD":
            switch(INV) {
                case "\u01A0":
                    type="dim";
                    break;
                case "\u01A1":
                    type="dim";
                    break;
                case "\u01BE":
                    type="dim7";
                    break;
                case "\u01A2":
                    type="dim7";
                    break;
                case "\u01A3":
                    type="dim7";
                    break;
                case "\u01A4":
                    type="dim7";
                    break;
                default:
                    type="dim";
                    break;
            }
            break;
        case "\u01BC":
            switch(INV) {
                case "\u01BC":
                    type="dim7";
                    break;
                case "\u01BD\u01A2":
                    type="dim7";
                    break;
                case "\u01BD\u01A3":
                    type="dim7";
                    break;
                case "\u01BD\u01A4":
                    type="dim7";
                    break;
            }
            break;
        case "\u01BF":
            switch(INV) {
                case "\u01A0":
                    type="aug";
                    break;
                case "\u01A1":
                    type="aug";
                    break;
                default:
                    type="aug";
                    break;
            }
            break;
        case "\u01C1":
            switch(INV) {
                case "\u01BE":
                    type="halfdim7";
                    break;
                case "\u01A2":
                    type="halfdim7";
                    break;
                case "\u01A3":
                    type="halfdim7";
                    break;
                case "\u01A4":
                    type="halfdim7";
                    break;
            }
            break;
        case "\u01C2":
            switch(INV) {
                case "\u01BE":
                    type="mM7";
                    break;
                case "\u01A2":
                    type="mM7";
                    break;
                case "\u01A3":
                    type="mM7";
                    break;
                case "\u01A4":
                    type="mM7";
                    break;
            }
            break;            
        default:
            if (MAJORS.indexOf(RN)!=-1) {
                switch(INV) {
                    case "\u01BE":
                        type="MAJ7";
                        break;
                    case "\u01A2":
                        type="MAJ7";
                        break;
                    case "\u01A3":
                        type="MAJ7";
                        break;
                    case "\u01A4":
                        type="MAJ7";
                        break;
                    default:
                        type="MAJ";
                        break;
                }
            }

            if (minors.indexOf(RN)!=-1) {
                switch(INV) {
                    case "\u01BE":
                        type="min7";
                        break;
                    case "\u01A2":
                        type="min7";
                        break;
                    case "\u01A3":
                        type="min7";
                        break;
                    case "\u01A4":
                        type="min7";
                        break;
                    default:
                        type="min";
                        break;
                }
            }

            if (AUG6.indexOf(RN)!=-1) {
                type=RN;
            }

            if (RN=="V") {
                switch(INV) {
                    case "\u01BE":
                        type="DOM7";
                        break;
                    case "\u01A2":
                        type="DOM7";
                        break;
                    case "\u01A3":
                        type="DOM7";
                        break;
                    case "\u01A4":
                        type="DOM7";
                        break;
                    default:
                        type="MAJ";
                        break;
                }
            }
            break;
    }
    return type;
}

function findRoot(RN,KEY) {
    var root;
    var scale=scaleMaker(KEY);
    if (KEY.indexOf('ʤ')!=-1) {
		if (scale[6].indexOf('\u266F')==-1 && scale[6].indexOf('ȱ')==-1)
			scale[6]=scale[6]+'\u266F';
		if (scale[6].indexOf('ȱ')!=-1)
			scale[6]=scale[6][0];
	}
    switch(RN) {
        case "I":
            root=scale[0];
            break;
        case "i":
            root=scale[0];
            break;
        case "ii":
            root=scale[1];
            break;
        case "N":
            root=notem(notem(notem(noteM(scale[0]))));
            break;
        case "iii":
            root=noteM(scale[0]);
            break;
        case "\u1D38III":
            root=notem(scale[0]);
            break;
        case "iv":
            root=scale[3];
            break;
        case "IV":
            root=scale[3];
            break;
        case "V":
            root=scale[4];
            break;
        case "v":
            root=scale[4];
            break;
        case "vi":
            root=scale[5];
            break;
        case "\u1D38VI":
            root=notem(scale[3]);
            break;
        case "Gr\u01BA":
            root=notem(scale[3]);
            break;
        case "Fr\u01BA":
            root=notem(scale[3]);
            break;
        case "It\u01BA":
            root=notem(scale[3]);
            break;
        case "vii":
            root=scale[6];
            break;
        case "\u1D38VII":
            root=notem(scale[4]);
            break;
    }
    return root;
}

function noteM(note) {
    var majorThird;
    switch(note) {
        case "C":
            majorThird="E";
            break;
        case "C\u0231":
            majorThird="E\u0231";
            break;
        case "C♯":
            majorThird="E♯";
            break;
        case "Cff":
            majorThird="Eff";
            break;
        case "Cx":
            majorThird="Ex";
            break;
        case "D":
            majorThird="F♯";
            break;
        case "D\u0231":
            majorThird="F";
            break;
        case "D♯":
            majorThird="Fx";
            break;
        case "Dff":
            majorThird="F\u0231";
            break;
        case "E":
            majorThird="G♯";
            break;
        case "E\u0231":
            majorThird="G";
            break;
        case "Eff":
            majorThird="G\u0231";
            break;
        case "E♯":
            majorThird="Gx";
            break;
        case "F":
            majorThird="A";
            break;
        case "F\u0231":
            majorThird="A\u0231";
            break;
        case "Fff":
            majorThird="Aff";
            break;
        case "Fx":
            majorThird="Ax";
            break;
        case "F♯":
            majorThird="A♯";
            break;
        case "G":
            majorThird="B";
            break;
        case "G\u0231":
            majorThird="B\u0231";
            break;
        case "G♯":
            majorThird="B♯";
            break;
        case "Gx":
            majorThird="Bx";
            break;
        case "Gff":
            majorThird="Bff";
            break;
        case "A":
            majorThird="C♯";
            break;
        case "A♯":
            majorThird="Cx";
            break;
        case "A\u0231":
            majorThird="C";
            break;
        case "Aff":
            majorThird="C\u0231";
            break;
        case "B":
            majorThird="D♯";
            break;
        case "B♯":
            majorThird="Dx";
            break;
        case "B\u0231":
            majorThird="D";
            break;
        case "Bff":
            majorThird="D\u0231";
            break;
    }
    return majorThird;
}

function notem(note) {
    var minorThird;
    switch(note) {
        case "C":
            minorThird="E\u0231";
            break;
        case "C\u0231":
            minorThird="Eff";
            break;
        case "C♯":
            minorThird="E";
            break;
        case "C#":
            minorThird="E";
            break;            
        case "Cx":
            minorThird="E♯";
            break;
        case "D":
            minorThird="F";
            break;
        case "D\u0231":
            minorThird="F\u0231";
            break;
        case "D♯":
            minorThird="F♯";
            break;
        case "Dff":
            minorThird="Fff";
            break;
        case "E":
            minorThird="G";
            break;
        case "E\u0231":
            minorThird="G\u0231";
            break;
        case "Eff":
            minorThird="Gff";
            break;
        case "E♯":
            minorThird="G♯";
            break;
        case "F":
            minorThird="A\u0231";
            break;
        case "F\u0231":
            minorThird="Aff";
            break;
        case "Fx":
            minorThird="A♯";
            break;
        case "F♯":
            minorThird="A";
            break;
        case "F#":
            minorThird="A";
            break;            
        case "G":
            minorThird="B\u0231";
            break;
        case "G\u0231":
            minorThird="Bff";
            break;
        case "G♯":
            minorThird="B";
            break;
        case "Gx":
            minorThird="B♯";
            break;
        case "Gff":
            minorThird="A\u0231";
            break;
        case "A":
            minorThird="C";
            break;
        case "A♯":
            minorThird="C♯";
            break;
        case "A\u0231":
            minorThird="C\u0231";
            break;
        case "Aff":
            minorThird="Cff";
            break;
        case "Ax":
            minorThird="Cx";
            break;
        case "B":
            minorThird="D";
            break;
        case "B♯":
            minorThird="D♯";
            break;
        case "B\u0231":
            minorThird="D\u0231";
            break;
        case "Bff":
            minorThird="Dff";
            break;
    }
    return minorThird;
}

function notea(note) {
    var aug6;
    switch(note) {
        case "C":
            aug6="A♯";
            break;
        case "C\u0231":
            aug6="A";
            break;
        case "D":
            aug6="B♯";
            break;
        case "D\u0231":
            aug6="B";
            break;
        case "E\u0231":
            aug6="C♯";
            break;
        case "E":
            aug6="Cx";
            break;
        case "Eff":
            aug6="C";
            break;
        case "F":
            aug6="D♯";
            break;
        case "F\u0231":
            aug6="D";
            break;
        case "G\u0231":
            aug6="E";
            break;
        case "G":
            aug6="E♯";
            break;
        case "Aff":
            aug6="F";
            break;
        case "A\u0231":
            aug6="F♯";
            break;
        case "A":
            aug6="Fx";
            break;
        case "B\u0231":
            aug6="G♯";
            break;
        case "B":
            aug6="Gx";
            break;
    }
    return aug6;
}

function chordBuild(root,type,inversion) {
    var chord;
    var r3=["B\u0231","B","B♯"];

    switch(type) {
        case "dim":
            chord=[root,notem(root),notem(notem(root))];
            break;
        case "dim7":
            chord=[root,notem(root),notem(notem(root)),notem(notem(notem(root)))];
            break;
        case "DOM7":
            chord=[root,noteM(root),notem(noteM(root)),notem(notem(noteM(root)))];
            break;
        case "halfdim7":
            chord=[root,notem(root),notem(notem(root)),noteM(notem(notem(root)))];
            break;
        case "aug":
            chord=[root,noteM(root),noteM(noteM(root))];
            break;
        case "min7":
            chord=[root,notem(root),noteM(notem(root)),notem(noteM(notem(root)))];
            break;
        case "MAJ7":
            chord=[root,noteM(root),notem(noteM(root)),noteM(notem(noteM(root)))];
            break;
        case "mM7":
			chord=[root,notem(root),noteM(notem(root)),noteM(noteM(notem(root)))]
			break;
        case "min":
            chord=[root,notem(root),noteM(notem(root))];
            break;
        case "MAJ":
            chord=[root,noteM(root),notem(noteM(root))];
            break;
        case "Gr\u01BA":
            chord=[root,noteM(root),notem(noteM(root)),notea(root)];
            break;
        case "Fr\u01BA":
            chord=[root,noteM(root),noteM(notem(noteM(notem(noteM(root))))),notea(root)];
            break;
        case "It\u01BA":
            chord=[root,noteM(root),notea(root)];
            break;
    }

    //for (var i=0; i<chord.length; i++) {
    //    if (r3.indexOf(root)==-1) chord[i]=chord[i]+"4";
    //    else chord[i]=chord[i]+"3";
    //}

    switch(inversion) {
        case "\u01A0":
            chord=invert(chord,1);
            break;
        case "\u01A1":
            chord=invert(chord,2);
            break;
        case "\u01BE":
            //var val=chord[3];
            //chord[3]=val.slice(0,val.length-1)+(1+parseInt(val[val.length-1]));
            break;
        case "\u01A2":
            chord=invert(chord,1);
            break;
        case "\u01A3":
            chord=invert(chord,2);
            break;
        case "\u01A4":
            chord=invert(chord,3);
            break;

        case "\u01BC":
            //var val=chord[3];
            //chord[3]=val.slice(0,val.length-1)+(1+parseInt(val[val.length-1]));
            break;
        case "\u01A2":
            chord=invert(chord,1);
            break;
        case "\u01A3":
            chord=invert(chord,2);
            break;
        case "\u01A4":
            chord=invert(chord,3);
            break;
        default:
            break;
    }
    return chord;
}

function invert(chord,num) {
    for (var i=0; i<num; i++) {
        chord.push(chord[i]);
        //var val=chord[chord.length-1];
        //chord[chord.length-1]=val.slice(0,val.length-1)+(1+parseInt(val[val.length-1]));
    }
    chord=chord.slice(num);
    return chord;
}

function dimRlabs(rlb,tog) {
	var op = tog ? 1 : 0.1;
	var ind = GS.chps.indexOf(rlb);
	for (var i=0; i<GS.chps.length; i++) {
		if (i==ind) continue;
		GS.chps[i].whole.attr({opacity:op});
	}
}

function findInd() {
	return GS.swbxs.indexOf(xSpace+105);
}

function modMenu(x,y,parent) {
	this.parent = parent;
	var stf = this.parent.parent;
	this.ary=[];
	var dis=this;
	this.onSum=false;
	var mods = ['\u01BD','\u01BF','\u01BE','\u01BC','\u01BB','\u01C0'];
    for (var i=0; i<mods.length; i++) {
        this.ary[i]=stf.text(56,85,mods[i]).attr({fill:'#000000','font-size':'16px',opacity:'0.0',fontFamily:'myFirstFont',fontWeight:'bold'});
        this.ary[i].rect=stf.rect(53,60,this.ary[i].getBBox().width+6,28,0).attr({opacity:'0.0',display:"none"});
        this.ary[i].attr({display:"none"});
        this.ary[i].rect.rom=this.ary[i];
        stf.group(this.ary[i],this.ary[i].rect);
        this.ary[i].hover(
			function() {dis.onSum=true;},
			function() {},
			null,null
        )
        this.ary[i].rect.hover(
            function(m) {
				dis.onSum=true;
                var sm=Snap(m.target);
                    //dis.hoverX=sm.matrix.e;
                    //dis.hoverY=sm.matrix.f;
                sm.animate({transform:'t'+sm.rom.x+' '+sm.rom.y+' s1.4'},55);
                sm.rom.animate({transform:'t'+sm.rom.x+' '+sm.rom.y+' s1.4'},55);

            },
            function(m) {
                var sm=Snap(m.target);
                //var tx=sm.matrix.e;
                //var ty=sm.matrix.f;
                sm.animate({transform:'t'+sm.rom.x+' '+sm.rom.y+' s1'},45);
                sm.rom.animate({transform:'t'+sm.rom.x+' '+sm.rom.y+' s1'},45);
				dis.onSum=false;
				setTimeout( function() {
					if (dis.onSum) return;
					if (getData(dis.parent.label)!=' ')
						dis.hide();
				},500);
			},null,null
        )        
        
        this.ary[i].rect.click(
            function(m) {
				var num = getData(dis.parent.label);
				var bnum = stripNum(num);
				//setData(dis.parent.label,bnum);
				var mod = Snap(m.target).rom.node.childNodes[0].data;
				/*if (num.indexOf(mod)!=-1) {
					setData(dis.parent.label,bnum);
					setData(dis.parent.clb.note.lhLbl.lbl,bnum);
					dis.parent.inv='';
					dis.parent.mod='';
					dis.parent.clb.note.inversion='';
					dis.parent.clb.note.mod='';
					dis.parent.centerLabel();
					dis.parent.rMenu.setKeySig();
					return;
				}*/
				
				//removing if inversion of seventh
				//var pivd=dis.parent.clb.note.pivved;
				//seventh
				if (mod=='\u01BE') {
					if (['\u01A2','\u01A3','\u01A4','\u01BE'].indexOf(dis.parent.inv)!=-1 && dis.parent.mod=='') {
						setData(dis.parent.label,bnum);
						dis.parent.inv='';
						dis.parent.mod='';
						dis.parent.centerLabel();
						return;						
					}
					dis.parent.inv = '\u01BE';
					dis.parent.mod = '';
				}
				//dim7
				if (mod=='\u01BC') {
					if (dis.parent.mod=='\u01BD' && dis.parent.inv=='\u01BE') {
						setData(dis.parent.label,bnum);
						dis.parent.inv='';
						dis.parent.mod='';
						dis.parent.centerLabel();
						return;						
					}
					dis.parent.inv = '\u01BE';
					dis.parent.mod = '\u01BD';
				}
				//augmented
				if (mod=='\u01BF') {
					if (dis.parent.mod=='\u01BF') {
						setData(dis.parent.label,bnum);
						dis.parent.inv='';
						dis.parent.mod='';
						dis.parent.centerLabel();
						return;						
					}					
					dis.parent.mod = '\u01BF';
					dis.parent.inv = '';
				}
				//M7
				if (mod=='\u01C0') {
					if (dis.parent.mod=='\u01C2') {
						setData(dis.parent.label,bnum);
						dis.parent.inv='';
						dis.parent.mod='';
						dis.parent.centerLabel();
						return;						
					}					
					dis.parent.inv = '\u01BE';
					dis.parent.mod = '\u01C2';
				}
				//hdim7
				if (mod=='\u01BB') {
					if (dis.parent.mod=='\u01C1') {
						setData(dis.parent.label,bnum);
						dis.parent.inv='';
						dis.parent.mod='';
						dis.parent.centerLabel();
						return;						
					}					
					dis.parent.inv = '\u01BE';
					dis.parent.mod = '\u01C1';
				}
				//dim
				if (mod=='\u01BD') {
					if (dis.parent.mod=='\u01BD' && dis.parent.inv=='') {
						setData(dis.parent.label,bnum);
						dis.parent.inv='';
						dis.parent.mod='';
						dis.parent.centerLabel();
						return;						
					}					
					dis.parent.inv = '';
					dis.parent.mod = '\u01BD';
				}
				setData(dis.parent.label,bnum+mod);
				//dis.hide();
				dis.parent.centerLabel();
				/*if (dis.parent.label.node.childNodes[0].data==Snap(m.target).rom.node.childNodes[0].data) {
					dis.parent.label.node.childNodes[0].data=" ";
					dis.parent.centerLabel();
					dis.hide();
					dis.parent.arrows.attr({display:'none',opacity:0});
					dis.parent.mtog=false;
					GS.dimStaff(1);
					dimRlabs(dis.parent,1);
					return;
				}
				dis.parent.label.node.childNodes[0].data=Snap(m.target).rom.node.childNodes[0].data;
				dis.parent.centerLabel();
				dis.hide();
				var txt = Snap(m.target).rom.node.childNodes[0].data;
				if (txt.indexOf('Fr')==-1 && txt.indexOf('Gr')==-1 && txt.indexOf('It')==-1)
					dis.parent.arrows.attr({display:'',opacity:1});
				dis.parent.mtog=false;
				GS.dimStaff(1);
				dimRlabs(dis.parent,1);*/
           
        })
    }
    this.pass=1;
    this.show = function() {
		if (getData(dis.parent.label).indexOf('It')!=-1) return;
		if (getData(dis.parent.label).indexOf('Fr')!=-1) return;
		if (getData(dis.parent.label).indexOf('Gr')!=-1) return;
		for (var z=0; z<GS.chps.length; z++)
			GS.chps[z].modMenu.hide();
        this.menuTog=true;
        //this.parent.rNum.num.attr({transform:'t0 0 s1'});
        //this.parent.rNum.numclr.attr({transform:'t0 0 s1'});
        var alpha=219*(3.14159/180);
        var radius=50;
        var incr=(130/this.ary.length)*(3.14159/180);
        var newX, newY;
        var adds, nadds, badds;
        for (var i=0; i<this.ary.length; i++) {
            newX = radius*Math.cos(alpha+i*incr);
            newY = radius*Math.sin(alpha+i*incr);
            this.ary[i].attr({display:""});
            this.ary[i].attr({transform:'t ' + (newX) + ' ' + (newY)});
            this.ary[i].attr({opacity:'1.0'});
            this.ary[i].rect.attr({display:""});
            dis.ary[i].rect.attr({'width':dis.ary[i].getBBox().width+8});
            this.ary[i].rect.attr({transform:'t ' + (newX) + ' ' + (newY)})
            if (dis.pass==1) {
                dis.ary[i].rect.rom.x=newX;
                dis.ary[i].rect.rom.y=newY;
            }            
        }
        dis.parent.sdline.attr({x2:dis.parent.sdx2-7,y2:dis.parent.sdy2+7});
        //dis.parent.sdline.attr({opacity:0.1});
        var txt = getData(dis.parent.label);
        if (txt.indexOf('Fr')==-1 && txt.indexOf('Gr')==-1 && txt.indexOf('It')==-1) {
			dis.parent.arrows.attr({display:''});
			dis.parent.arrows.attr({opacity:1});
		}
        this.pass=2;
    };
    this.hide = function() {
        this.menuTog=false;
        //for (var i=0; i<this.ary.length; i++) {
        //    this.ary[i].animate({transform:'t0 0'},0,mina.backin);
        //    this.ary[i].animate({opacity:'0.0'},0);
        //}
        dis.parent.sdline.attr({x2:dis.parent.sdx2,y2:dis.parent.sdy2});
        dis.parent.sdline.attr({opacity:1});
        dis.parent.arrows.attr({opacity:0});
       // setTimeout(function() {
            for (var i=0; i<dis.ary.length; i++) {
                dis.ary[i].attr({display:'none'}); dis.ary[i].rect.attr({display:"none"});
            }
            //setTimeout(function() {
				dis.parent.arrows.attr({display:'none'}); 
			//},125);
            //dis.whole.append(dis.numeralC);
        //},0);
    }  
    this.whole=stf.group();
    for (var i=0; i<this.ary.length; i++) {
        this.whole.append(this.ary[i]);
        this.whole.append(this.ary[i].rect);
    }
    this.x = x; this.y = y;
    this.whole.transform('t'+x+' '+y);      	
}

function getBass(g) {
	var trebleStarts = [556];		// Where Treble clefs start (M376, M374)
	var children = g.node.childNodes;
	var check;
	var c2;
	for (var j = 0; j < children.length; j++) {
		if (children[j].nodeName == 'path') {
			// DECEMBER 12 EDIT
			//if (trebleStarts.indexOf(children[j].pathSegList[0].x) != -1) {
			//	break;
			//}
			check = children[j].getAttribute('d').split(' ')[0];
			c2 = check.length;
			if (trebleStarts.indexOf(parseInt(check.slice(1,c2))) != -1) {
				break;
			}
		}
	}
	return children[j];	
}

var xSpace=0;
function fbHover(parent,Ndx,gs) {
	var dis = this;
	this.index = Ndx;
	var xtra;
	var h = 10;
	var adds=0;
	if (Ndx>21) adds=35;
	this.y=69.7+Ndx*h+adds;
	var noteNames=[null,null,null,null,'C','B','A','G','F','E','D','C','B','A','G','F','E','D','C','B','A','G','F','E','D','C','B','A','G','F','E','D','C','B','A','G','F','E'];
	var midiNums=[null,null,null,null,84,83,81,79,77,76,74,72,71,69,67,65,64,62,60,59,57,55,53,52,50,48,47,45,43,41,40,38,36,35,33,31,29,28];
	var notePlaces=[52.5,57.5,62.5,67.5,72.5,77.5,82.5,87.5,92.5,97.5,102.5];	
	
	var LedgersT = [4,5,6,18,19,20,21,22,23,24,25,37];
	//switch(Ndx) {
	//	case 0:
	//		xtra=
	//}
	//this.minus = S.text(247.5,this.y+4,'-');
	//var adds=0;
	//if (xndx>3) adds=23;
	//var adds=0;
	//if (Ndx>20) this.y+=adds;
	this.r = parent.whole.rect(140,this.y,510,h,0).attr({opacity:0.0,stroke:'black'});
	this.r.hover(
		function(m) {
			if (KEYMENUOPEN) return;
			if (RMENUOPEN) return;
			if (xSpace>0) {
				for (var i=0; i<GS.hrects.length; i++) {
					if (GS.hrects[i].note) {
						GS.hrects[i].note.remove();
						GS.hrects[i].note=null;
					}
					if (GS.hrects[i].ledgers) {
						for (var j=0; j<GS.hrects[i].ledgers.length; j++)
							GS.hrects[i].ledgers[j].remove();
							//GS.hrects[i]
					}
				}				
				return;
			}
			//dis.r.attr({stroke:'white'});
			//if (parent.moveNote) {
			for (var i=0; i<GS.chps.length; i++)
				if (GS.chps[i].rMenu.menuTog) return;
			for (var i=0; i<GS.hrects.length; i++) {
				if (GS.hrects[i].note) {
					GS.hrects[i].note.remove();
					GS.hrects[i].note=null;
				}
				if (GS.hrects[i].ledgers) {
					for (var j=0; j<GS.hrects[i].ledgers.length; j++)
						GS.hrects[i].ledgers[j].remove();
						//GS.hrects[i]
				}
			}
			//if (GS.basses[findInd()])
			//	if (dis.y > GS.basses[findInd()].y) return;
			//if (GS.basses[0] && GS.sopranos[0] && GS.tenors[0] && GS.altos[0]) return;
			if (GS.startNotes.length==4) return;
			//if (!GS.basses[findInd()] && dis.index < 22) return;
			//if (GS.basses.length==7 && GS.tenors.length==7 && GS.altos.length==7 && GS.sopranos.length==7
			//	&& GS.basses.indexOf(null)==-1 && GS.altos.indexOf(null)==-1 && GS.tenors.indexOf(null)==-1 && GS.sopranos.indexOf(null) == -1
			//) return;
			//if (GS.basses.length!=7 && GS.basses[findInd()]) return;
			//if (GS.basses[findInd()] && GS.tenors[findInd()] && GS.altos[findInd()] && GS.sopranos[findInd()]) return;
			//findPlace(GS.swbxs)
			//if (!dis.note)
			var p = closedPath;
			var add = 0; var yadd=0;
			dis.cover = false;
			var nX = add+xSpace+GS.trebleStaff.sharps.length*18;
			//if (findInd()==6) { p = noteOpen; add = -7.5; yadd = 0.3; } //dis.cover = true;}
			
			dis.note=parent.whole.path(p).transform('t'+(nX+9+add-3*yadd)+' '+(dis.y+0.35+yadd)+' s0.07 -0.07');
			dis.note.attr({opacity:0.5});
			if (LedgersT.indexOf(dis.index)!=-1) {
				dis.ledgers=[];
				switch(dis.index) {
					case 4:
						dis.ledgers.push(parent.whole.line(nX+157,dis.y,nX+190,dis.y).attr({stroke:'black'}));
						dis.ledgers.push(parent.whole.line(nX+157,dis.y+20,nX+190,dis.y+20).attr({stroke:'black'}));
						break;
					case 5:
						dis.ledgers.push(parent.whole.line(nX+157,dis.y+10,nX+190,dis.y+10).attr({stroke:'black'}));
						break;
					case 6:
						dis.ledgers.push(parent.whole.line(nX+157,dis.y,nX+190,dis.y).attr({stroke:'black'}));
						break;
					case 21:            //F
						dis.ledgers.push(parent.whole.line(nX+157,dis.y-10,nX+190,dis.y-10).attr({stroke:'black'}));
						dis.ledgers.push(parent.whole.line(nX+157,dis.y-30,nX+190,dis.y-30).attr({stroke:'black'}));
						break;
					case 20:            //E
						dis.ledgers.push(parent.whole.line(nX+157,dis.y,nX+190,dis.y).attr({stroke:'black'}));
						dis.ledgers.push(parent.whole.line(nX+157,dis.y-20,nX+190,dis.y-20).attr({stroke:'black'}));					
						break;
					case 19:            //D
						dis.ledgers.push(parent.whole.line(nX+157,dis.y-10,nX+190,dis.y-10).attr({stroke:'black'}));
						break;          
					case 18:		    //C
						dis.ledgers.push(parent.whole.line(nX+157,dis.y,nX+190,dis.y).attr({stroke:'black'}));
						break;
					case 22:            //F
						dis.ledgers.push(parent.whole.line(nX+157,dis.y+10,nX+190,dis.y+10).attr({stroke:'black'}));
						dis.ledgers.push(parent.whole.line(nX+157,dis.y+30,nX+190,dis.y+30).attr({stroke:'black'}));
						break;
					case 23:            //E
						dis.ledgers.push(parent.whole.line(nX+157,dis.y,nX+190,dis.y).attr({stroke:'black'}));
						dis.ledgers.push(parent.whole.line(nX+157,dis.y+20,nX+190,dis.y+20).attr({stroke:'black'}));					
						break;
					case 24:            //D
						dis.ledgers.push(parent.whole.line(nX+157,dis.y+10,nX+190,dis.y+10).attr({stroke:'black'}));
						break;          
					case 25:		    //C
						dis.ledgers.push(parent.whole.line(nX+157,dis.y,nX+190,dis.y).attr({stroke:'black'}));
						break;
					case 37:
						dis.ledgers.push(parent.whole.line(nX+157,dis.y,nX+190,dis.y).attr({stroke:'black'}));
						break;
				}
				for (var i=0; i<dis.ledgers.length; i++)
					dis.ledgers[i].attr({opacity:0.5});
			}
			//dis.note.stem=parent.whole.rect(0,0,2.5,45).transform('t'+(add+xSpace+163+GS.trebleStaff.sharps.length*18)+' '+(dis.y+1.55)).attr({opacity:0.5});
			dis.whole.append(dis.note);
			//GS.bassStaff.whole.append(dis.note);
			//GS.whole.append(dis.note);
			dis.note.click(
				function() {
					for (var i=0; i<GS.hrects.length; i++) {
						if (GS.hrects[i].note) {
							GS.hrects[i].note.remove();
							GS.hrects[i].note=null;
						}
						if (GS.hrects[i].ledgers) {
							for (var j=0; j<GS.hrects[i].ledgers.length; j++)
								GS.hrects[i].ledgers[j].remove();
								//GS.hrects[i]
						}
					}
					var ind = findInd();
					var add = 0;
					var x = add+xSpace+9+GS.trebleStaff.sharps.length*18+180;
					
					if (GS.startNotes.length<4)
						GS.startNotes.push(stfNote(parent,x,dis.y,p,dis,null,ind));
					sortStartNotes();
				}				
			)
		},
		function() {
			/*for (var i=0; i<GS.hrects.length; i++)
				if (GS.hrects[i].note) {
					GS.hrects[i].note.remove();
					GS.hrects[i].note=null;
				}*/
			//dis.r.attr({stroke:'none'});
		},
		null,null
	)
	this.r.click(
				function() {
					if (KEYMENUOPEN) return;
					if (RMENUOPEN) return;
					if (xSpace>0) return;
					for (var i=0; i<GS.hrects.length; i++) {
						if (GS.hrects[i].note) {
							GS.hrects[i].note.remove();
							GS.hrects[i].note=null;
						}
						if (GS.hrects[i].ledgers) {
							for (var j=0; j<GS.hrects[i].ledgers.length; j++)
								GS.hrects[i].ledgers[j].remove();
						}
					}					
					if (GS.basses[0] && GS.sopranos[0] && GS.tenors[0] && GS.altos[0]) return;
					var add = 0;
					var ind = 0;
					var x = add+xSpace+9+GS.trebleStaff.sharps.length*18+180;
					var p = closedPath;
					if (GS.startNotes.length<4)
						GS.startNotes.push(stfNote(parent,x,dis.y,p,dis,null,ind));
					sortStartNotes();
					/*if (GS.basses[ind]) {
						if (dis.index>21) {
							GS.tenors[ind]=stfNote(parent,x,dis.y,p,dis,'t',ind);
							return;
						}
						if (GS.sopranos[ind]) {
							GS.altos[ind]=stfNote(parent,x,dis.y,p,dis,'s',ind);
							sortTreble(GS.altos,GS.sopranos);
							return;
						} else {
							GS.sopranos[ind]=stfNote(parent,x,dis.y,p,dis,'a',ind);
							sortTreble(GS.altos,GS.sopranos);
							return;
						}
					} else {
						GS.basses[ind]=stfNote(parent,x,dis.y,p,dis,'b',ind);
						return;
					}*/
				}
	)
	this.whole=S.group(this.r); //,this.pc,this.plus,this.plus2,this.mc,this.minus,this.mClr,this.pClr,this.noteBox);
}

function sortTreble(altos,sopranos) {
	for (var i=0; i<7; i++) {
		if (altos[i]==undefined || sopranos[i]==undefined) continue
		var tmp = altos[i];
		if (tmp.y < sopranos[i].y) {
			altos[i]=sopranos[i];
			altos[i].type='a';
			sopranos[i]=tmp;
			sopranos[i].type='s';
		}
	}
}

function setSig(key, tstf, bstf) {
	var keyS=keySig(key);
	
	if (GS)
		GS.keyMenu.key.attr({opacity:0});
	var fs="";
    var scale=scaleMaker(key);
    for (var i=0; i<scale.length; i++) {
        if (scale[i].indexOf("♯")!=-1) fs="sharp";
        if (scale[i].indexOf("♭")!=-1) fs="flat";
    }
    
    if (tstf.sharps) {
		for (var i=0; i<tstf.sharps.length; i++) {
			tstf.sharps[i].remove();
			tstf.sharps[i]=null;
			
			bstf.sharps[i].remove();
			bstf.sharps[i]=null;
		}
		tstf.sharps=[];
		bstf.sharps=[];
	}
	
	if (tstf.flats) {
		for (var i=0; i<tstf.flats.length; i++) {
			tstf.flats[i].remove();
			tstf.flats[i]=null;
			
			bstf.flats[i].remove();
			bstf.flats[i]=null;
		}
		tstf.flats=[];
		bstf.flats=[];
	}
	
	var axf=[170.5,155.5,175.5,160.5,180.5,165.5,185.5];
	var axs=[150.5,180.5,140.5,170.5,200.5,160.5,190.5];
	switch(fs) {
		case "sharp":
			setTimeout(function() {
				for (var i=0; i<keyS.length; i++) {
					tstf.sharps.push(tstf.whole.path(sharpPath).attr({transform:'t'+(18*i)+' '+(axs[i])+' s0.07 -0.07',opacity:0}));
					bstf.sharps.push(bstf.whole.path(sharpPath).attr({transform:'t'+(18*i)+' '+(axs[i]+244.5)+' s0.07 -0.07',opacity:0}));
					
					tstf.sharps[i].animate({opacity:1},200);
					bstf.sharps[i].animate({opacity:1},200);
				}
			},650);
			break;
	}
	
	//move the shit
	setTimeout(function() {
		var time=300;
		for (var i=0; i<GS.chps.length; i++) {
			GS.chps[i].whole.animate({transform:'t'+(keyS.length*18)+' 0'},time,mina.backin);
			//GS.chps[i].rMenu.whole.animate({transform:'t'+(GS.chps[i].rMenu.x+keyS.length*18)+' '+GS.chps[i].rMenu.y},time,mina.backin);
		}
		var vAry = [GS.sopranos,GS.altos,GS.tenors,GS.basses];
		for (var i=0; i<vAry.length; i++)
			for (var j=0; j<vAry[i].length; j++) {
				vAry[i][j].animate({transform:'t'+(vAry[i][j].x+keyS.length*18)+' '+vAry[i][j].y+'s0.07 -0.07'},time,mina.backin);
				if (vAry[i][j].ledgers)
					for (var k=0; k<vAry[i][j].ledgers.length; k++)
						vAry[i][j].ledgers[k].animate({transform:'t'+(-vAry[i][j].ledgers[k].x+keyS.length*18)+' 0'},time,mina.backin);
			}
		var newW = tstf.width+keyS.length*18;
		for (var i=0; i<tstf.lines.length; i++) {
			tstf.lines[i].animate({width:tstf.width+keyS.length*18},time,mina.backin);
			bstf.lines[i].animate({width:tstf.width+keyS.length*18},time,mina.backin);
		}
		GS.width = newW;
		GS.endBar.animate({transform:'t'+(keyS.length*18)+' 0'},time,mina.backin);
		GS.endBar2.animate({transform:'t'+(keyS.length*18)+' 0'},time,mina.backin);
		GS.barLine.animate({transform:'t'+(keyS.length*18)+' 0'},time,mina.backin);
		setTimeout(function() {
			GS.centerStaff();
		}, time+250, mina.backout);
		//for (var i=0; GS.hrects.length; i++) {
		//	GS.hrects[i].r.transform('t'+keyS.length*18+' 0');
		//}		
	},50);
}

function addAx(note,x,y,ax) {
	if (note.sharp) note.sharp.remove();
	if (note.flat) note.flat.remove();
	if (note.doubleSharp) note.doubleSharp.remove();
	if (note.doubleFlat) note.doubleFlat.remove();
	note.arrowUp.attr({display:''});
	//note.arrowUpClr.attr({display:''});
	note.arrowDown.attr({display:''});
	//note.arrowDownClr.attr({display:''});
	switch(ax) {
		case '♯':
			note.sharp = GS.whole.path(sharpPath).transform('t'+(x-180)+' '+y+' s0.07 -0.07');
			break;
		case '♭':
			note.flat = GS.whole.path(flatPath).transform('t'+(x-130)+' '+(y-162)+' s0.069 -0.069');
			break;
		case 'x':
			note.doubleSharp = GS.whole.path(doublesharpPath).transform('t'+(x-80)+' '+(y-307)+' s0.39 -0.39');
			note.arrowUp.attr({display:'none'});
			//note.arrowUpClr.attr({display:'none'});
			break;
		case 'bb':
			note.doubleFlat = GS.whole.path(doubleflatPath).transform('t'+(x-122)+' '+(y-342)+' s0.36 0.36');
			note.arrowDown.attr({display:'none'});
			//note.arrowDownClr.attr({display:'none'});
			break;
	}
}

function scaleMaker(tonic) {
    var scale = ["A","B","C","D","E","F","G"];

    var shrp = ["C","G","D","A","E","B","F♯","C♯"];
    var flat = ["C","F","B♭","E♭","A♭","D♭","G♭","C♭"];

    var sloc = [0,2,18,19,27,91,95,127];
    var floc = [0,32,36,100,108,109,125,127];

    var pos;

    switch(tonic[tonic.length-1]) {
        case "♯":
            pos = dec2Bin(sloc[shrp.indexOf(tonic)]);
            var t=pos.length;
            for (var i=0; i<7-t; i++) pos="0"+pos;
            for (var i=0; i<pos.length; i++) {
                if (pos[i]==1)
                    scale[i]=scale[i]+"♯";
            }
            break;
        case "♭":
            pos = dec2Bin(floc[flat.indexOf(tonic)]);
            var t=pos.length;
            for (var i=0; i<7-t; i++) pos="0"+pos;
            for (var i=0; i<pos.length; i++) {
                if (pos[i]==1)
                    scale[i]=scale[i]+"♭";
            }
            break;
        case "F":
            pos = dec2Bin(floc[flat.indexOf(tonic)]);
            var t=pos.length;
            for (var i=0; i<7-t; i++) pos="0"+pos;
            for (var i=0; i<pos.length; i++) {
                if (pos[i]==1)
                    scale[i]=scale[i]+"♭";
            }
            break;
        default:
            pos = dec2Bin(sloc[shrp.indexOf(tonic)]);
            var t=pos.length;
            for (var i=0; i<7-t; i++) pos="0"+pos;
            for (var i=0; i<pos.length; i++) {
                if (pos[i]==1)
                    scale[i]=scale[i]+"♯";
            }
            break;
    }
    scale=scale.slice(scale.indexOf(tonic)).concat(scale.slice(0,scale.indexOf(tonic)));
    return scale;
}

function stfNote(parent,x,y,p,dis,type,ndx) {
	var LedgersT = [4,5,6,18,19,20,21,22,23,24,25,37];
	var noteNames=[null,null,null,null,'C','B','A','G','F','E','D','C','B','A','G','F','E','D','C','B','A','G','F','E','D','C','B','A','G','F','E','D','C','B','A','G','F','E'];
	var midiNums=[null,null,null,null,72,71,69,67,65,64,62,60,59,57,55,53,52,50,48,47,45,43,53,52,50,48,47,45,43,41,40,38,36,35,33,31,29,28];
	var notePlaces=[52.5,57.5,62.5,67.5,72.5,77.5,82.5,87.5,92.5,97.5,102.5];
	if (ndx == 6) x-=0.6;	
	var note = parent.whole.path(p).transform('t'+(x-180)+' '+(y+0.55)+' s0.07 -0.07');
	note.x = x-180-keySig(getData(GS.keyMenu.key)).length*18;
	note.y = y+0.55;
	if (ndx == 6) x+=9;
	note.ledgers=[];
	//var nX = x;
	if (LedgersT.indexOf(dis.index)!=-1) {
		switch(dis.index) {
			case 4:
				note.ledgers.push(parent.whole.line(x-33,dis.y,x,dis.y).attr({stroke:'black'}));
				note.ledgers.push(parent.whole.line(x-33,dis.y+20,x,dis.y+20).attr({stroke:'black'}));
				break;
			case 5:
				note.ledgers.push(parent.whole.line(x-33,dis.y+10,x,dis.y+10).attr({stroke:'black'}));
				break;
			case 6:
				note.ledgers.push(parent.whole.line(x-33,dis.y,x,dis.y).attr({stroke:'black'}));
				break;
			case 21:            //F
				note.ledgers.push(parent.whole.line(x-33,dis.y-10,x,dis.y-10).attr({stroke:'black'}));
				note.ledgers.push(parent.whole.line(x-33,dis.y-30,x,dis.y-30).attr({stroke:'black'}));
				break;
			case 20:            //E
				note.ledgers.push(parent.whole.line(x-33,dis.y,x,dis.y).attr({stroke:'black'}));
				note.ledgers.push(parent.whole.line(x-33,dis.y-20,x,dis.y-20).attr({stroke:'black'}));					
				break;
			case 19:            //D
				note.ledgers.push(parent.whole.line(x-33,dis.y-10,x,dis.y-10).attr({stroke:'black'}));
				break;          
			case 18:		    //C
				note.ledgers.push(parent.whole.line(x-33,dis.y,x,dis.y).attr({stroke:'black'}));
				break;
			case 22:            //F
				note.ledgers.push(parent.whole.line(x-33,dis.y+10,x,dis.y+10).attr({stroke:'black'}));
				note.ledgers.push(parent.whole.line(x-33,dis.y+30,x,dis.y+30).attr({stroke:'black'}));
				break;
			case 23:            //E
				note.ledgers.push(parent.whole.line(x-33,dis.y,x,dis.y).attr({stroke:'black'}));
				note.ledgers.push(parent.whole.line(x-33,dis.y+20,x,dis.y+20).attr({stroke:'black'}));					
				break;
			case 24:            //D
				note.ledgers.push(parent.whole.line(x-33,dis.y+10,x,dis.y+10).attr({stroke:'black'}));
				break;          
			case 25:		    //C
				note.ledgers.push(parent.whole.line(x-33,dis.y,x,dis.y).attr({stroke:'black'}));
				break;
			case 37:
				note.ledgers.push(parent.whole.line(x-33,dis.y,x,dis.y).attr({stroke:'black'}));
				break;
		}
	}	
	
	note.arrowUp = parent.whole.polyline(x,y-3.8, x+4,y-5.8, x+8,y-3.8).attr({fill:'none',stroke:'black',strokeWidth:2});
	note.arrowUpClr = parent.whole.rect(x-15,y-13,35,13).attr({opacity:0.1});
	note.arrowUpClr.click(
		function() {
			var nd = findInd();
			if (note.arrowUp.attr('display')=='none') return;
			var nN = newName(note.name,1);
			note.name = nN[0];
			note.midiNbr+=1;
			addAx(note,x,y,nN[1]);
		}
	)
	/*GS.basses[ind].arrowUpClr.hover(
		function() {
			var nd = findInd();
			note.arrowUp.transform('t0 0 s1.2');
		},
		function() {
			var nd = findInd();
			note.arrowUp.transform('t0 0 s1');
		},
		null,null
	)*/
	note.arrowDown = parent.whole.polyline(x,y+4.2, x+4,y+6.2, x+8,y+4.2).attr({fill:'none',stroke:'black',strokeWidth:2});
	note.arrowDownClr = parent.whole.rect(x-15,y,35,13).attr({opacity:0.1});
	note.arrowDownClr.click(
		function() {
			var nd = findInd();
			if (note.arrowDown.attr('display')=='none') return;
			var nN = newName(note.name,-1);
			note.name = nN[0];
			note.midiNbr-=1;
			addAx(note,x,y,nN[1]);
		}
	)
	/*note.arrowDownClr.hover(
		function() {
			var nd = findInd();
			if (note.OnN) return;
			note.arrowDown.transform('t0 0 s1.2');
		},
		function() {
			var nd = findInd();
			note.arrowDown.transform('t0 0 s1');
		},
		null,null
	)*/					
	note.arrowGroup = parent.whole.group(note.arrowUp,note.arrowDown,note.arrowUpClr,note.arrowDownClr);
	var dd = note;
	//setTimeout(
	//	function() {
	//		if (dd.On) return;
	dd.arrowGroup.attr({display:'none'});
	//	},1000
	//)
	note.arrowGroup.hover(
		function() {
			var nd = findInd();
			note.On=true;
		},
		function() {
			var nd = findInd();
			note.On=false;
			setTimeout(function() {
				var nd = findInd();
				if (note.On) return;
				note.arrowGroup.attr({display:'none'});
			},0)
		},
		null,null
	)
	note.On=false;
	
	note.y = y;
	//note.type = type;
	note.name = noteNames[dis.index];
	note.midiNbr = midiNums[dis.index];
	note.click(
		function() {
			var nd = findInd();
			switch(note.type) {
				case 'b':
					GS.basses[nd]=null;
					break;
				case 't':
					GS.tenors[nd]=null;
					break;
				case 'a':
					GS.altos[nd]=null;
					break;
				case 's':
					GS.sopranos[nd]=null;
					break;
			}
			GS.startNotes.splice(GS.startNotes.indexOf(note),1);
			sortStartNotes();
			note.remove();
			if (note.sharp) { note.sharp.remove(); note.sharp=null; }
			if (note.flat) { note.flat.remove(); note.flat=null; }
			if (note.doubleSharp) { note.doubleSharp.remove(); note.doubleSharp=null; }
			if (note.doubleFlat) { note.doubleFlat.remove(); note.doubleFlat=null; }
			for (var i=0; i<note.ledgers.length; i++)
				note.ledgers[i].remove();
			note.ledgers=[];
			note.arrowGroup.remove();
			note=null;
		}
	)
	note.hover(
		function() {
			return;
			for (var i=0; i<GS.hrects.length; i++) {
				if (GS.hrects[i].note) {
					GS.hrects[i].note.remove();
					GS.hrects[i].note=null;
				}
				if (GS.hrects[i].ledgers) {
					for (var j=0; j<GS.hrects[i].ledgers.length; j++)
						GS.hrects[i].ledgers[j].remove();
						//GS.hrects[i]
				}
			}			
			var nd = findInd();
			note.On=true;
			note.OnN=true;
			note.arrowGroup.attr({display:''});
			GS.whole.append(note.arrowGroup);	
		},
		function() {
			return;
			var nd = findInd();
			note.On=false;
			note.OnN=false;
			setTimeout(function() {
				var nd = findInd();
				if (note.On) return;
				note.arrowGroup.attr({display:'none'});
			},0)
		},
		null,null
	)					
	for (var i=0; i<note.ledgers.length; i++) {
		GS.bassStaff.whole.append(note.ledgers[i]);
		note.ledgers[i].x = keySig(getData(GS.keyMenu.key)).length*18;
	}
	GS.bassStaff.whole.append(note);
	GS.whole.append(note);
	return note;
}

function sortStartNotes() {
	var nts = GS.startNotes;
	nts.sort(function(a,b){return b.y-a.y})
	var types = ['b','t','a','s'];
	var arys = [GS.basses,GS.tenors,GS.altos,GS.sopranos];
	for (var i=0; i<nts.length; i++) {
		nts[i].type=types[i];
		arys[i][0]=nts[i];
		//if (nts[i].y>=324.7)
		//	GS.bassStaff.whole.append(nts[i]);
	}
}

function findScaleDegrees() {
	getUserSolution();
	var scale = scaleMaker(getData(GS.keyMenu.key));
	var int1 = findInterval(GS.altos[0],GS.basses[0],scale);
}

function findInterval(n1,n2,scale) {
	var num1 = n1.midiNbr;
	var num2 = n2.midiNbr;
	var name1 = n1.name;
	var name2 = n2.name;
	
	var ind1 = scale.indexOf(name1)+1;
	var ind2 = scale.indexOf(name2);
	
	if (ind1==-1)
		ind1 = scale.indexOf(name1[0])+1;
	if (ind2==-1)
		ind2 = scale.indexOf(name2[0]);
	
	if (num1-num2 > 11) ind1+=7;
	if (num1-num2 > 23) ind1+=7;
	var int = ind1-ind2;
	var str;
	switch(int) {
		case 2:
			str='nd';
			break;
		case 3:
			str='rd';
			break;
		case 8:
			str='ve';
			break;
		default:
			str='th';
			break;
	}
	return int+str;
}

function newName(name,dir) {
	if (name.indexOf('♭')==-1 && name.indexOf('bb')==-1 && name.indexOf('x')==-1 && name.indexOf('♯')==-1) {
		switch(dir) {
			case 1:
				return [name+='♯','♯'];
				break;
			case -1:
				return [name+='♭','♭'];
				break;
		}
	}
	if (name.indexOf('♯')!=-1) {
		switch(dir) {
			case 1:
				return [name.split('♯')[0]+='x','x'];
				break;
			case -1:
				return [name.split('♯')[0],''];
				break;
		}
	}
	if (name.indexOf('♭')!=-1) {
		switch(dir) {
			case 1:
				return [name.split('♭')[0],''];
				break;
			case -1:
				return [name.split('♭')[0]+='bb','bb'];
				break;
		}
	}
	if (name.indexOf('bb')!=-1) {
		return [name.split('bb')[0]+='♭','♭'];
	}
	if (name.indexOf('x')!=-1) {
		return [name.split('x')[0]+='♯','♯'];
	}
}

function findAx(notes) {
	var ary=[0,0,0,0];
	for (var i=0; i<notes.length-1; i++) {
		if (notes[i].sharp) ary[i]=1;
		if (notes[i].flat) ary[i]=2; 
	}
	return ary;
}

function arySum(array) {
	var count=0;
	for (var i=array.length; i--;) {
		count+=array[i];
	}
}

function changeSD(obj,inout) {
	switch(inout) {
		case 1:
			if (getData(obj.label)!=" ") {
				obj.rMenu.hide();
				setTimeout(function() {
					setAry(obj.rMenu.romAry,obj.rMenu.sdroms);
					obj.rstate='SD';
					obj.rMenu.show();
				},400)
			}
			obj.label.attr({'font-size':'12px'});
			obj.arrows.transform('t-19 -14 s0.7');
			obj.clr.attr({width:25,height:30});
			obj.sdline.attr({display:''});
			obj.sdlabel.attr({display:''});
			obj.sdClr.attr({display:''});
			moveEle(obj.label, 0, -14);
			break;
		case 0:
			obj.label.attr({'font-size':'18px'});
			obj.arrows.transform('t0 0');
			obj.clr.attr({width:40,height:33});
			obj.sdline.attr({display:'none'});
			obj.sdlabel.attr({display:'none'});
			obj.sdClr.attr({display:'none'});			
			moveEle(obj.label, 0, 14);
			break;
	}
	obj.SD=inout;
	obj.centerLabel();
}

function moveEle(e, dx, dy) {
	e.node.transform.baseVal[0].matrix.e += dx;
	e.node.transform.baseVal[0].matrix.f += dy;
}

//Paths
var treblePath = "M374 260c5 0 10 1 15 1c154 0 254 -127 254 -259c0 -76 -33 -153 -107 -208c-22 -17 -47 -29 -73 -37c3 -36 5 -72 5 -108c0 -19 0"
		+ " -37 -1 -56c-7 -120 -88 -226 -206 -226c-108 0 -195 87 -195 195c0 58 53 104 112 104c54 0 95 -48 95 -104c0 -52 -43 -95 -95 -95 c-12 0 -24"
		+ " 4 -35 9c26 -41 70 -70 121 -70c96 0 157 93 163 193c1 18 2 35 2 53c0 32 -2 64 -5 96c-29 -5 -58 -8 -89 -8c-188 0 -333 171 -333 372c0 178 133"
		+ " 306 251 440c-18 63 -35 126 -42 191c-6 51 -7 102 -7 154c0 116 55 226 150 295c2 2 5 3 8 3s6 -1 8 -3c70 -84 132 -246 132 -359c0 -144 -87 -256"
		+ " -183 -365c20 -69 39 -138 55 -208zM459 -205c69 24 117 96 117 166c0 92 -69 184 -179 193c25 -117 48 -235 62 -359zM71 31c0 -136 131 -251 267"
		+ " -251c28 0 55 2 82 6c-15 128 -38 247 -64 367c-79 -9 -125 -62 -125 -121c0 -44 26 -92 82 -124c4 -4 7 -9 7 -14c0 -11 -9 -21 -20 -21c-3 0 -6 1"
		+ " -9 2c-80 43 -116 114 -116 184c0 88 57 173 158 196c-14 60 -30 119 -46 178c-108 -121 -216 -242 -216 -402zM411 1050c-99 -50 -161 -151 -161"
		+ " -262c0 -76 15 -137 33 -200c82 97 149 198 149 325 c0 58 -4 84 -21 137z";
var bassPath = "M556 -125c0 29 23 52 52 52s52 -23 52 -52s-23 -52 -52 -52s-52 23 -52 52zM556 125c0 29 23 52 52 52s52 -23 52"
		+ " -52s-23 -52 -52 -52s-52 23 -52 52zM233 261c171 0 292 -86 292 -248c0 -263 -264 -415 -517 -521c-2 -2 -5 -3 -8 -3c-6 0 -11"
		+ " 5 -11 11c0 3 1 6 3 8 c203 118 415 265 415 494c0 121 -64 237 -174 237c-79 0 -138 -57 -164 -133c14 8 28 13 43 13c55 0 100"
		+ " -45 100 -100c0 -58 -44 -107 -100 -107c-60 0 -112 48 -112 107c0 132 103 242 233 242z";
var fourPath="M204 307c22 14 44 29 60 50c11 15 19 33 27 50c2 4 5 6 9 6c6 0 13 -5 13 -14v-245h72c10 0 15 -7 15 -14s-5 -15 -15 -15h-72v-8c0 -48 27 -94 72 -94c8 0 12 -5 12 -11s-4 -12 -12 -12c-44 0 -87 13 -131 13s-87 -13 -131 -13c-8 0 -12 6 -12 12s4 11 12 11 "+
			 "c45 0 73 46 73 94v8h-167c-23 0 -31 14 -31 23c0 3 1 5 2 6c80 93 138 207 138 330c0 9 6 16 13 16h3c23 -7 47 -13 71 -13s48 6 71 13c2 1 3 1 5 1c11 0 18 -10 12 -17l-284 -330h167v131c0 8 1 17 8 22z";
//var threePath="M150 477c-29 0 -59 -8 -59 -33c0 -22 36 -25 36 -47c0 -32 -26 -58 -58 -58s-57 26 -57 58c0 65 67 103 138 103c91 0 169 -33 169 -114c0 -43 -4 -82 -42 -100c-9 -4 -14 -12 -14 -21s5 -18 14 -22c41 -19 56 -57 56 -103c0 -92 -79 -140 -179 -140 "+
//        + " c-79 0 -154 42 -154 113c0 36 30 66 66 66s65 -30 65 -66c0 -25 -40 -28 -40 -53c0 -27 32 -37 63 -37c49 0 63 61 63 117v16c0 54 -2 94 -50 94h-80c-10 0 -14 8 -14 15s4 14 14 14h80c49 0 50 43 50 99v8c0 54 -18 91 -67 91z";
var threePath="M150 477c-29 0 -59 -8 -59 -33c0 -22 36 -25 36 -47c0 -32 -26 -58 -58 -58s-57 26 -57 58c0 65 67 103 138 103c91 0 169 -33 169 -114c0 -43 -4 -82 -42 -100c-9 -4 -14 -12 -14 -21s5 -18 14 -22c41 -19 56 -57 56 -103c0 -92 -79 -140 -179 -140c-79 0 -154 42 -154 113c0 36 30 66 66 66s65 -30 65 -66c0 -25 -40 -28 -40 -53c0 -27 32 -37 63 -37c49 0 63 61 63 117v16c0 54 -2 94 -50 94h-80c-10 0 -14 8 -14 15s4 14 14 14h80c49 0 50 43 50 99v8c0 54 -18 91 -67 91z";
var bracePath="M-12 -640c0 -344 -132 -684 -132 -1012c0 -176 40 -336 156 -472c4 -4 8 -8 8 -12c0 -8 -12 -20 -20 -20c-4 0 -8 4 -12 8c-156 180 -212 408 -212 644c0 352 136 696 136 1028c0 172 -40 332 -156 468c0 4 -4 4 -4 8s4 4 4 8c116 136 156 296 156 468c0 332 -136 676 -136 1028c0 236 56 464 212 644c4 4 8 8 12 8c8 0 20 -12 20 -20c0 -4 -4 -8 -8 -12c-116 -136 -156 -296 -156 -472c0 -328 132 -668 132 -1012c0 -236 -56 -460 -208 -640c152 -180 208 -404 208 -640z";

//notes
var closedPath = "M224 136c53 0 105 -26 105 -86c0 -71 -57 -122 -104 -150c-36 -22 -78 -36"
	+ " -120 -36c-53 0 -105 26 -105 86c0 71 58 122 105 150c36 22 77 36 119 36z";
var noteOpen = "m 315,65 c 0,24 -21,41 -42,41 -4,0 -8,0 -12,-1 C 230,96 184,65 147,41"
	+ " 110,17 63,-12 43,-37 36,-45 32,-55 32,-65 c 0,-24 21,-41 42,-41 4,0 8,0 12,1 31,9"
	+ " 78,40 115,64 37,24 84,53 104,78 7,8 10,18 10,28 z m -51,72 c 47,0 83,-21 83,-72"
	+ " 0,-19 -4,-37 -10,-56 -12,-38 -32,-74 -65,-96 -54,-36 -113,-51 -188,-51 -47,0 -84,22"
	+ " -84,73 0,19 5,37 11,56 12,38 31,74 64,96 54,36 114,50 189,50 z";
		
//accidentals
var flatPath = "M27 41l-1 -66v-11c0 -22 1 -44 4 -66c45 38 93 80 93 139c0 33 -14 67 -43 67c-31 0 -52 -30 -53 -63zM-15 -138l-12 595c8"
        + " 5 18 8 27 8s19 -3 27 -8l-7 -345c25 21 58 34 91 34c52 0 89 -48 89 -102c0 -80 -86 -117 -147 -169c-15 -13 -24 -38 -45 -38 c-13 0 -23 11 -23 25z";

var sharpPath = "M215 -316c0 -9 -8 -17 -17 -17s-17 8 -17 17v151l-87 -31v-162c0 -9 -8 -17 -17 -17s-17 8 -17 17v150l-39"
		+ " -13c-10 -4 -21 4 -21 15v64c0 7 5 13 11 15l49 18v164l-39 -14c-10 -4 -21 4 -21 15v65c0 7 5 13 11 15l49 17v163c0 9 8"
		+ " 17 17 17s17 -8 17 -17v-151l87 31v162 c0 9 8 17 17 17s17 -8 17 -17v-150l39 13c10 4 21 -4 21 -15v-64c0 -7 -5 -13 -11"
		+ " -15l-49 -18v-164l39 14c10 4 21 -4 21 -15v-65c0 -7 -5 -13 -11 -15l-49 -17v-163zM94 67v-164l87 30v164z";	
var doublesharpPath = "M63.4219 333.7031 L43.5938 333.7031 L43.5938 321.4688 Q43.5938 315.8438 36 315.8438 Q33.6094 315.8438"
        + " 31.2188 317.3906 Q28.4062 319.2188 28.4062 321.4688 L28.4062 333.7031 L9.4219 333.7031 L9.4219 314.7188 L21.6562"
        + " 314.7188 Q27.2812 314.7188 27.2812 307.125 Q27.2812 304.7344 25.5938 302.1328 Q23.9062 299.5312 21.6562 299.5312"
        + " L9.4219 299.5312 L9.4219 280.4062 L28.4062 280.4062 L28.4062 292.6406 Q28.4062 294.8906 31.2188 296.7188 Q33.6094"
        + " 298.2656 36 298.2656 Q43.5938 298.2656 43.5938 292.6406 L43.5938 280.4062 L63.4219 280.4062 L63.4219 299.5312 L51.1875"
        + " 299.5312 Q48.9375 299.5312 47.25 302.1328 Q45.5625 304.7344 45.5625 307.125 Q45.5625 314.7188 51.1875 314.7188 L63.4219"
        + " 314.7188 L63.4219 333.7031 Z";
var doubleflatPath = "M28.125 392.4844 L28.125 266.625 L35.4375 266.625 L35.4375 352.4062 L42.4688 343.6875 Q49.2188 337.5 56.5312 337.5"
        + " Q61.3125 337.5 65.9531 339.6094 Q70.5938 341.7188 72.8438 346.3594 Q75.0938 351 75.0938 357.4688 Q74.8125 364.2188 68.625 371.25"
        + " Q62.4375 378.2812 51.1875 383.9062 Q39.9375 389.5312 28.125 392.4844 ZM75.9375 392.4844 L75.9375 266.625 L83.25 266.625 L83.25"
        + " 352.4062 L90.2812 343.6875 Q97.0312 337.5 104.3438 337.5 Q109.125 337.5 113.7656 339.6094 Q118.4062 341.7188 120.6562 346.3594"
        + " Q122.9062 351 122.9062 357.4688 Q122.625 364.2188 116.4375 371.25 Q110.25 378.2812 99 383.9062 Q87.75 389.5312 75.9375 392.4844"
        + " ZM35.4375 378.8438 Q51.4688 373.3594 56.9531 367.6641 Q62.4375 361.9688 62.4375 358.0312 Q62.4375 355.2188 62.0156 353.5312"
        + " Q61.5938 351.8438 59.7656 350.2969 Q57.9375 348.75 55.6875 348.75 Q53.4375 348.75 49.7812 350.1562 Q46.125 351.5625 43.5938"
        + " 354.0938 L35.4375 362.25 L35.4375 378.8438 ZM83.25 378.8438 Q99.2812 373.3594 104.7656 367.6641 Q110.25 361.9688 110.25"
        + " 358.0312 Q110.25 355.2188 109.8281 353.5312 Q109.4062 351.8438 107.5781 350.2969 Q105.75 348.75 103.5 348.75 Q101.25 348.75"
        + " 97.5938 350.1562 Q93.9375 351.5625 91.4062 354.0938 L83.25 362.25 L83.25 378.8438 Z";
var naturalPath = "M-8 375c8 4 17 7 26 7s17 -3 25 -7l-3 -183l106 20h3c10 0 18 -7 18 -17l7 -570c-8 -4 -16 -7 -25 -7s-17 3 -25 7l3 183l-106 -20h-3c-10 0 -18 7 -18 17zM131 112l-92 -17l-3 -207l92 17z";

//Grads
var rnGrad2 = "l(0,0.5,1,0.5)#A0AFB3-#000000";
var rnGrad3 = "l(-0.25,-0.25,1.25,1.25)#A0AFB3-#FFFFFF";
