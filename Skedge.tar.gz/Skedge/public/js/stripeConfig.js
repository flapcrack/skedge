var handler;
var myAmt;
var myPurchases;
function stripeConfigure() {  
  myAmt = 2520;
  handler = StripeCheckout.configure({
    key: 'pk_test_ZrCibT16pROyxFvvcET579oa',
    //image: '/img/documentation/checkout/marketplace.png',
    image: "images/p.png",
    //https://stripe.com/img/documentation/checkout/marketplace.png
    locale: 'auto',
    token: function(token) {
       //token.amount=myAmt
       token.amount = GS.price
       //myAmt += 75
       console.log(token)
       console.log(JSON.stringify(token.id))
      // You can access the token ID with `token.id`.
      // Get the token ID to your server-side code for use.
       //sendJSON('/charge', token)
       var json = '{ "token": "' + token.id + '", "amt":"' + GS.price + '",'
          +  '"email":"' + token.email + '", "skus":"' + GS.sku + '"}'
       //stripePost(json, function() {ProductWindow.purchaseComplete()})
       stripePost(json, function() {})
      // post(JSON.stringify(token.id))
    }
  });

  // Close Checkout on page navigation:
  $(window).on('popstate', function() {
  window.on
    handler.close();
  });
}

function stripePost(value, callback) {
  var http = new XMLHttpRequest();

  // It would be better to use JSON.stringify to properly generate
  // a JSON string
  /**
  var value = JSON.stringify({
      prop1: 'value 1',
      prop2: 'value 2'
  });
  **/
  //console.log('stripePOST ' + value)

  http.open('POST', '/charge', true);
  http.setRequestHeader('Content-Type', 'application/json; charset=utf-8');
  //http.setRequestHeader('Content-Length', value.length);
  http.onreadystatechange = function () {
      if (http.readyState == 4 && http.status == 200) {
          //alert('****POSTED Charge' + http.responseText);
          var txt = http.responseText
          console.log('CHARGE: ' + txt)
          //ProductWindow.purchaseComplete(txt)
          //callback('Here it is')
      }
  }
  http.send(value); 
}
