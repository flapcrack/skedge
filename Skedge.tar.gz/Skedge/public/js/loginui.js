// LoginUI
var LoginUI, LoginButton
window.addEventListener('DOMContentLoaded', function() {
    var lbtn
    LoginUI = new function() {
        var uiDiv, uDiv, tdArrow, dropDiv, img, uname, uemail
        uiDiv = HTML.div(null,null,'width:250px;position:absolute;display:none;top:5px;;background:white')
        uDiv = HTML.div(uiDiv,null,'border:1px solid #dcdcdc;')
        uDiv.onclick = function() {         // Toggle DropDown DIV
            if (tdArrow.innerText == '\u25BE') {
                dropDiv.style.display = 'block'
                tdArrow.innerText = '\u25B4'    // Up Arrow
            } else {
                tdArrow.innerText = '\u25BE' 
                dropDiv.style.display = 'none'
            }
        }
        var tbl = HTML.table(uDiv); var tr = HTML.tr(tbl); var td = HTML.td(tr)  // top,right,bot,left
        img = HTML.img(td,null,'width:50px;height:50px;padding:5px 5px 1px 7px;')
        td = HTML.td(tr)
        d = HTML.div(tr,null,'width:160px;margin-top:auto;display:table-cell;vertical-align:middle')
        uname = HTML.span(d,'','font-weight:bold;font-family:arial;font-size:14px')
        HTML.br(d)
        uemail = HTML.span(d,'','font-family:arial;color:#67696b;font-size:13px;')
        tdArrow = HTML.td(tr,'\u25BE')       // 25B4 up
        dropDiv = HTML.div(uiDiv,null,'border-left:1px solid #dcdcdc;border-bottom:1px solid #dcdcdc;'
            + 'border-right:1px solid #dcdcdc;height:52px;display:none;background:white')
        tbl = HTML.table(dropDiv)
        tr = HTML.tr(tbl);  
        td = HTML.td(tr,'Manage account','font-family:arial;font-size:14px;color:#3b7fed;opacity:0.25;'
            + 'padding:6px 10px')
        tr = HTML.tr(tbl)
        td = HTML.td(tr,'Sign out','font-family:arial;font-size:14px;color:#3b7fed;padding:0px 10px')
        td.onclick = function() { firebase.auth().signOut() }       // Does Firebase SignOut
        uiDiv.style.display = 'none'

        this.update = function(u) {
            img.src = u.photoURL
            uname.innerText = u.displayName
            uemail.innerText = (u.email.length>22) ? u.email.slice(0,22)+'...' : u.email;
            uiDiv.style.display = 'block'
            lbtn.style.visibility = 'hidden'
        }
        this.show = function(tf) {
            uiDiv.style.display = tf ? 'block' : 'none' 
            lbtn.style.visibility = tf ? 'hidden' : ''
        }
        var resizeUI = function() {
            uiDiv.style.left = (window.innerWidth - 260) + 'px'
        }
        resizeUI()
        window.addEventListener('resize', resizeUI)
    }
    LoginButton = new function() {
        lbtn = HTML.button(null,'Sign In','background-color:#becadd;border-radius:4px;'
        +'border:1px solid #dcdcdc;font: 16px "Helvetica Neue",helvetica,arial,sans-serif;'
        +'font-weight:bold;padding: 0 10px;height:32px;margin:0;color:#444;position:absolute;'
        +'min-width:54px;display:none;text-align:center;white-space:nowrap;'
        +'visibility:hidden;top:5px') 
        lbtn.style.left = (window.innerWidth - 80) + 'px'  
        lbtn.onclick = signInWithRedirect
        this.show = function(tf) {
            lbtn.style.visibility = tf ?  '' : 'hidden'
        }  
        var position = function(tf) {
            lbtn.style.left = (window.innerWidth - 80) + 'px'  
            LoginUI.show(!tf)  
        }
        //position()
        //window.addEventListener('resize', position)
    }
})

//************************************************************************** */
// HTML
//************************************************************************** */
var HTML = new function() {
    this.ele = function(typ, parent, txt, css, before) {
        var ele, e
        ele = document.createElement(typ)
        if (css) ele.style.cssText = css
        if (before) {
            before.parentNode.insertBefore(ele, before)
        } else {
            if (parent)
                parent.appendChild(ele)
            else
                document.body.appendChild(ele)
        }
        if (['button','header','label','td','p','span'].indexOf(typ) != -1) {
            if (txt) {
                var t = document.createTextNode(txt)
                ele.appendChild(t)
            }
        }
        return ele
    }
    var ele = this.ele
    this.text = function(div,txt,css) { var e = ele('div',div,txt,css); if (txt) e.innerHTML = txt }
    this.label = function(div,txt,css) { var e = ele('label',div,txt,css) }
    this.button = function(div,txt,css,id,click) { var e = ele('button',div,txt,css); 
        if (id) e.id = id; if (click) e.onclick = function(e) { click(e) }; return e }
    this.radio = function(div,id,txt,click) { var e = ele('input',div); e.type = 'radio';
        if (id) e.id = id; 
        if (txt) { e.label = ele('span',div,txt); e.label.innerHTML = txt; }
        if (click) e.onclick = function(e) { click(e) }
        return e
    }
    this.input = function(div,css,txt) { var e = ele('input',div,null,css); 
        if (txt) e.value = txt; return e }
    this.div = function(div,before,css) { return ele('div',div,null,css,before) }
    this.br = function(div) { return ele('br',div) }
    this.header = function(div,txt,css) { return ele('header',div,txt,css) }
    this.table = function(div,before) { return(ele('table',div,null,null,before)) }
    this.tr = function(tbl) { return(ele('tr',tbl)) }
    this.td = function(tr,txt,css) { return ele('td',tr,txt,css) }
    this.html = function(ele,txt,css) { ele.innerHTML = txt }
    this.p = function(div,txt,css) { return ele('p',div,txt,css) }
    this.img = function(div,src,css) { var e = ele('img',div,null,css); if (src) e.src = src; return e}
    this.span = function(div,txt,css) {return ele('span',div,txt,css)}
}

//**********************************************************************************************
// xhrGET and xhrPOST Main routines
//**********************************************************************************************
var net = new function() {
    this.GET = function(url, callback, errHandler) {
        var xhr = new XMLHttpRequest();
        xhr.open("GET", url, true);
        //if (txt) {
        //    xhr.setRequestHeader("idToken", txt);
            //console.log(txt)
        //}
    
        xhr.onreadystatechange = function() {
            if (xhr.readyState == 4) {
                if (xhr.status == 200) {
                    if (!callback) 
                        console.log(xhr.responseText)
                    else
                        callback(xhr.responseText)
                } else if (xhr.status == 404) {
                    if (errHandler)
                        errHandler(xhr)
                    //return xhr.responseText
                }
            }
        }
        xhr.send();        
    }
    this.POST = function xhrPOST(url, txt, callback) {
        var xhr = new XMLHttpRequest();
        xhr.open("POST", url, true);
        xhr.onreadystatechange = function() {
            if (xhr.readyState == 4) {
                if (xhr.status != 200) {
                    console.log('POST err: ' + url + ' status:' + xhr.status)
                } else {
					callback();
				}
            }
        }		
        xhr.setRequestHeader("Content-Type", "application/json; charset=UTF-8"); 	
        xhr.send(txt);
    }    
}
