exports.solver = solver;

//build constraints, make an .lp file, call lp-solver, return skedges
function solver(obj) {
	var STUDIOS=['Hache','Hartgraves','Novak','Parrish','Ulen','Vassian'];
	var ACCOMPANISTS=['Wang','McNally','Dennis','Quesada','Anderson','Choi','Ashley','Kayla','Eric','Joey','Grace'];
	var stds = [
		[2,1,1,1,1,0], //wang
		[1,1,1,1,0,1], //mcnally
		[1,1,3,0,1,1], //dennis
		[1,1,0,1,1,1], //quesada
		[1,0,1,1,1,1], //anderson
		[0,1,1,1,1,1], //choi
		[0,3,0,0,0,0], //ashley
		[1,0,0,0,2,0], //kayla
		[0,0,1,3,0,0], //eric
		[1,0,0,0,0,0], //joey
		[0,0,0,0,1,3]  //grace
	];
	//var NUMBER_IN_STUDIO=[1,3,7,2,3,5];//obj.numbers;	
	var slots=8;
    //obj has which students are singing in each studio, and who their accompanist is
    //number of students in each studio is only important thing, who plays and when will be determined later
    
    //accompanist plays for all singers they have
    var cstr='min: ';
    //make cost function, prefer to pack schedule towards the front
    for (var i=0; i<ACCOMPANISTS.length; i++) {
		for (var j=0; j<STUDIOS.length; j++) {
			for (var z=0; z<slots; z++) {
				cstr += ((z+1)*(z+1)*(z+1)*(z+1)) + ' ' + ACCOMPANISTS[i] + '_' + STUDIOS[j] + z;
				if (z!=(slots-1)) cstr+=' + ';
			}
			if (j!=(STUDIOS.length-1)) cstr+=' + ';
		}
		if (i!=(ACCOMPANISTS.length-1)) cstr+=' + ';
	}
	cstr+=';\n';
	//console.log(cstr);
    
    var binstr='bin ';
    for (var i=0; i<ACCOMPANISTS.length; i++) {
		for (var j=0; j<STUDIOS.length; j++) {
			for (var z=0; z<slots; z++) {
				cstr += ACCOMPANISTS[i] + '_' + STUDIOS[j] + z;
				binstr += ACCOMPANISTS[i] + '_' + STUDIOS[j] + z;
				if (z!=(slots-1)) { cstr+=' + '; binstr+=', '; }
				else { cstr+=' = '; }
			}
			if (j!=(STUDIOS.length-1)) binstr+=', ';
			cstr+=stds[i][j]+';';
			cstr+='\n';
		}
		if (i!=(ACCOMPANISTS.length-1)) binstr+=', ';
		else binstr+=';';
	}
	//console.log(cstr);
	
	//one accompanist per time slot
	var tstr='';
	for (var z=0; z<slots; z++) {
		for (var i=0; i<STUDIOS.length; i++) {
			for (var j=0; j<ACCOMPANISTS.length; j++) {
				tstr += ACCOMPANISTS[j] + '_' + STUDIOS[i] + z;
				if (j!=(ACCOMPANISTS.length-1)) tstr+=' + ';
				else tstr+=' <= ';
			}
			tstr+='1;';
			tstr+='\n';
		}
	}
	//console.log(tstr);
	
	//accompanist can't be two places at one time
	var rstr='';
	for (var z=0; z<slots; z++) {
		for (var i=0; i<ACCOMPANISTS.length; i++) {
			for (var j=0; j<STUDIOS.length; j++) {
				rstr += ACCOMPANISTS[i] + '_' + STUDIOS[j] + z;
				if (j!=(STUDIOS.length-1)) rstr+=' + ';
				else rstr+=' <= ';
			}
			rstr+='1;';
			rstr+='\n';
		}
	}
	//console.log(rstr);
	var lpStr = cstr+tstr+rstr+'\n'+binstr;
	return lpStr;
}
