function xhrGET(url, callback) {
	var xhr = new XMLHttpRequest();
	xhr.open("GET", url, true);
	xhr.onreadystatechange = function() {
		if (xhr.readyState == 4) {
			if (xhr.status == 200) {
				if (!callback) 
					console.log(xhr.responseText)
				else
					callback(xhr.responseText)
			} else if (xhr.status == 404) {
				//return xhr.responseText
			}
		}
	}
	xhr.send();
}

function xhrPOST(url, txt, callback) {
	var xhr = new XMLHttpRequest();
	xhr.open("POST", url, true);
	xhr.onreadystatechange = function() {
		if (xhr.readyState == 4) {
			if (xhr.status != 200) {
				console.log('xhrPOST err: ' + url + ' status:' + xhr.status)
			} else {
				if (callback)
					callback(xhr.responseText)
			}
		}
	}	
	xhr.setRequestHeader("Content-Type", "application/json; charset=UTF-8");
	xhr.send(txt);
}