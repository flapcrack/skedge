exports.solver = solver;

//build constraints, make an .lp file, call lp-solver, return skedges
function solver(obj) {
	var STUDIOS=['Hache','Hartgraves','Novak','Parrish','Ulen','Vassian'];
	var ACCOMPANISTS=['Wang','McNally','Dennis','Quesada','Anderson','Choi','Ashley','Kayla','Eric','Joey','Grace'];
	//dummy data for now, will be json
	var singers = ['Anna','Anarra','Sara','James','Jaimie','Kelly','Rachel','Alex','Mackenzie','Emily','Hunter','Thomas','Sean','Jenn','Gustavo','Pierce','Tylar','Bethany','Sean R','Anai','Brittney','Nathan','Ben','Carlos','Jack','Bronson','John','Woody','Chris','Isaac','Marilyn','Obi-Wan','Derp1','Derp2','Derp3','Derp4','Derp5','Derp6','Derp7','Derp8','Derp9','Derp10','Derp11','Derp12','Derp13','Derp14','Derp15','Derp16','Derp17'];
	var accomps = ['Wang','McNally','Dennis','Quesada','Anderson','Choi','Ashley','Kayla','Eric','Joey','Grace'];
	//make obj
	var snd, sbj, stm;
	var snums = [8,5,10,12,6,8];
	var stms = [1,1,1,1,1,1];
	var input = {};
	var scnt=0;
	for (var i=0; i<STUDIOS.length; i++) {
		input[STUDIOS[i]] = [];
		while(input[STUDIOS[i]].length!=snums[i]) {
			sbj={};
			sbj.name=singers[scnt];
			sbj.time=stms[i];
			sbj.acc=accomps[Math.floor(accomps.length*Math.random())];
			input[STUDIOS[i]].push(sbj);
			scnt++;
		}
	}	
	
	
	/*for (var i=0; i<singers.length; i++) {
		snd = STUDIOS[i%6];
		sbj = {};
		sbj.name = singers[i];
		//sbj.time = Math.floor(2*Math.random())+1; //times can range from 5-10 minutes
		sbj.time = Math.floor(3*Math.random())+1;
		sbj.acc = accomps[i%7];
		input[snd].push(sbj);
	}*/
	//console.log(JSON.stringify(input));
	//return;
	
	//build arrays for accompanists
	var stds = [];
	var NSTD = [];
	var tmp;
	var ntmp;
	var atm;
	var TIMES = [];
	var stu;
	for (var i=0; i<ACCOMPANISTS.length; i++) {
		tmp=[0,0,0,0,0,0];
		ntmp=[0,0,0,0,0,0];
		atm=[[],[],[],[],[],[]];
		for (var j=0; j<STUDIOS.length; j++) {
			stu=input[STUDIOS[j]];
			for (var k=0; k<stu.length; k++) {
				if (stu[k].acc==ACCOMPANISTS[i]) {
					tmp[j]+=stu[k].time;
					ntmp[j]+=1;
					atm[j].push(stu[k].time);
				}
			}
		}
		stds.push(tmp);
		NSTD.push(ntmp);
		TIMES.push(atm);
		console.log(ACCOMPANISTS[i]+': '+tmp+', '+ntmp);
	}
	/*
	//console.log(stds);
	//console.log(NSTD);
	//return;
	
	//console.log(singers.length);
	*/
	/*var stds = [
		[1,1,0,0,0,0], //wang
		[0,0,0,0,0,1], //mcnally
		[0,1,2,0,0,0], //dennis
		[0,0,2,1,0,0], //quesada
		[0,0,0,0,0,0], //anderson
		[0,0,0,2,2,0], //choi
		[0,0,0,0,0,0], //ashley
		[0,0,0,0,0,0], //kayla
		[0,0,0,0,0,0], //eric
		[0,0,0,0,0,0], //joey
		[0,0,0,0,2,1]  //grace
	];
	
	var NSTD = [
		[1,1,0,0,0,0],
		[0,0,0,0,0,1],
		[0,1,1,0,0,0],
		[0,0,1,1,0,0],
		[0,0,0,0,0,0],
		[0,0,0,1,1,0],
		[0,0,0,0,0,0],
		[0,0,0,0,0,0],
		[0,0,0,0,0,0],
		[0,0,0,0,0,0],
		[0,0,0,0,1,1]
	];
	
	var TIMES = [
		[[1],[1],[],[],[],[]],
		[[],[],[],[],[],[1]],
		[[],[1],[2],[],[],[]],
		[[],[],[2],[1],[],[]],
		[[],[],[],[],[],[]],
		[[],[],[],[2],[2],[]],
		[[],[],[],[],[],[]],
		[[],[],[],[],[],[]],
		[[],[],[],[],[],[]],
		[[],[],[],[],[],[]],
		[[],[],[],[],[2],[1]]
	];*/
	
	//console.log(stds);
	//console.log(NSTD);	
	//var NUMBER_IN_STUDIO=[1,3,7,2,3,5];//obj.numbers;	
	var slots=global.SLOTS;
    //obj has which students are singing in each studio, and who their accompanist is
    //number of students in each studio is only important thing, who plays and when will be determined later
    
    var cstr='min: ';
    //make cost function, prefer to pack schedule towards the front
    /*for (var i=0; i<ACCOMPANISTS.length; i++) {
		for (var j=0; j<STUDIOS.length; j++) {
			for (var z=0; z<slots; z++) {
				cstr += ((z+1)*(z+1)*(z+1)*(z+1)) + ' ' + ACCOMPANISTS[i] + '_' + STUDIOS[j] + z;
				if (z!=(slots-1)) cstr+=' + ';
			}
			if (j!=(STUDIOS.length-1)) cstr+=' + ';
		}
		if (i!=(ACCOMPANISTS.length-1)) cstr+=' + ';
	}*/
	cstr+=';\n';
	//console.log(cstr);
    
    //accompanists play for all singers they have
    //define binary variables
    var binstr='bin ';
    for (var i=0; i<ACCOMPANISTS.length; i++) {
		for (var j=0; j<STUDIOS.length; j++) {
			for (var z=0; z<slots; z++) {
				cstr += ACCOMPANISTS[i] + '_' + STUDIOS[j] + z;
				binstr += ACCOMPANISTS[i] + '_' + STUDIOS[j] + z; //regular variables
				//binstr += ', ';
				//binstr += 'aSPEC' + ACCOMPANISTS[i] + '_' + STUDIOS[j] + z;
				if (z!=(slots-1)) { cstr+=' + '; binstr+=', '; }
				else { cstr+=' = '; }
			}
			if (j!=(STUDIOS.length-1)) binstr+=', ';
			cstr+=stds[i][j]+';';
			cstr+='\n';
		}
		if (i!=(ACCOMPANISTS.length-1)) binstr+=', ';
		//else binstr+=';';
	}
	binstr += ', ';
	//console.log(cstr);
	
	//ensure contiguous variables
	/*for (var i=0; i<ACCOMPANISTS.length; i++) {
		for (var j=0; j<STUDIOS.length; j++) {
			for (var z=0; z<slots-1; z++) {
				cstr += 'SPEC' + ACCOMPANISTS[i] + '_' + STUDIOS[j] + z;
				if (z!=(slots-2)) { cstr+=' + '; }
				else { cstr+=' = '; }
			}
			cstr+=NSTD[i][j]+';';
			cstr+='\n';
		}
	}*/
	for (var i=0; i<ACCOMPANISTS.length; i++) {
		for (var j=0; j<STUDIOS.length; j++) {
			ACCOMPANISTS[i] + '_' + STUDIOS[j] + '0 = ' + 'SPEC' + ACCOMPANISTS[i] + '_' + STUDIOS[j] + '0;\n'; 
			//for (var z=0; z<slots-2; z++) {
			//	//cstr += ACCOMPANISTS[i] + '_' + STUDIOS[j] + z + ' <= ' + 'SPEC' + ACCOMPANISTS[i] + '_' + STUDIOS[j] + z + ' + ' + ACCOMPANISTS[i] + '_' + STUDIOS[j] + (z-1) + ';\n';
			//	var ast = ACCOMPANISTS[i] + '_' + STUDIOS[j];
			//	cstr += ast + z + ' - ' + ast + (z+1) + ' + ' + ast + (z+2) + ' <= 1;';
			//}
		}
	}
	
	//cstr += 'aSPECDennis_Novak0 Dennis_Novak0 + aSPECDennis_Novak0 Dennis_Novak1 + aSPECDennis_Novak1 Dennis_Novak1 + aSPECDennis_Novak1 Dennis_Novak2 + aSPECDennis_Novak2 Dennis_Novak2 + aSPECDennis_Novak2 Dennis_Novak3 + aSPECDennis_Novak3 Dennis_Novak3 + aSPECDennis_Novak3 Dennis_Novak4 + aSPECDennis_Novak4 Dennis_Novak4 + aSPECDennis_Novak4 Dennis_Novak5 + aSPECDennis_Novak5 Dennis_Novak5 + aSPECDennis_Novak5 Dennis_Novak6 + aSPECDennis_Novak6 Dennis_Novak6 + aSPECDennis_Novak6 Dennis_Novak7 + aSPECDennis_Novak7 Dennis_Novak7 + aSPECDennis_Novak7 Dennis_Novak8 + aSPECDennis_Novak8 Dennis_Novak8 + aSPECDennis_Novak8 Dennis_Novak9 + aSPECDennis_Novak9 Dennis_Novak9 + aSPECDennis_Novak9 Dennis_Novak10 + aSPECDennis_Novak10 Dennis_Novak10 + aSPECDennis_Novak10 Dennis_Novak11 + aSPECDennis_Novak11 Dennis_Novak11 + aSPECDennis_Novak11 Dennis_Novak12 + aSPECDennis_Novak12 Dennis_Novak12 + aSPECDennis_Novak12 Dennis_Novak13 + aSPECDennis_Novak13 Dennis_Novak13 + aSPECDennis_Novak13 Dennis_Novak14 + aSPECDennis_Novak14 Dennis_Novak14 + aSPECDennis_Novak14 Dennis_Novak15 = 2;\n';
	
	//one starting point
	var T;
	var ast;
	var pv = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'];
	for (var i=0; i<ACCOMPANISTS.length; i++) {
		for (var j=0; j<STUDIOS.length; j++) {
			for (var n=0; n<TIMES[i][j].length; n++) {
				T = TIMES[i][j][n];
				ast = ACCOMPANISTS[i]+'_'+STUDIOS[j];
				cstr += pv[n]+'SPEC'+ast+'0';
				binstr += pv[n]+'SPEC'+ast+'0, ';
				for (var z=1; z<slots-T+1; z++) {
					cstr += ' + ';
					cstr += pv[n]+'SPEC'+ast+z;
					binstr += pv[n]+'SPEC'+ast+z+', ';
				}
				cstr += ' = 1;\n';
				
				if (T>1) {
					for (var ii=0; ii<slots-T; ii++) {
						for (var jj=ii; jj<ii+T; jj++) {
							cstr += pv[n]+'ZPEC'+ast+ii+'_'+jj;
							binstr += pv[n]+'ZPEC'+ast+ii+'_'+jj+', ';
							if (jj<ii+T-1) cstr += ' + ';
						}
						if (ii<slots-T-1) cstr += ' + ';
						else cstr += ' = ' + T + ';\n';
					}
					for (var ii=0; ii<slots-T; ii++) {
						for (var jj=ii; jj<ii+T; jj++) {
							cstr+=pv[n]+'ZPEC'+ast+ii+'_'+jj+' <= '+pv[n]+'SPEC'+ast+ii+';\n';
							cstr+=pv[n]+'ZPEC'+ast+ii+'_'+jj+' <= '+ast+jj+';\n';
							cstr+=pv[n]+'ZPEC'+ast+ii+'_'+jj+' >= '+pv[n]+'SPEC'+ast+ii+' + '+ast+jj+' - 1;\n';
						}
					}
				} else {
					for (var ii=0; ii<slots-T; ii++) {
						cstr += pv[n]+'ZPEC'+ast+ii+'_'+ii;
						binstr += pv[n]+'ZPEC'+ast+ii+'_'+ii+', ';
						if (ii<slots-T-1) cstr += ' + ';
						else cstr += ' = ' + T + ';\n';
					}
					for (var ii=0; ii<slots-T; ii++) {
						cstr+=pv[n]+'ZPEC'+ast+ii+'_'+ii+' <= '+pv[n]+'SPEC'+ast+ii+';\n';
						cstr+=pv[n]+'ZPEC'+ast+ii+'_'+ii+' <= '+ast+ii+';\n';
						cstr+=pv[n]+'ZPEC'+ast+ii+'_'+ii+' >= '+pv[n]+'SPEC'+ast+ii+' + '+ast+ii+' - 1;\n';
					}
				}
			}
		}
	}
	for (var i=0; i<ACCOMPANISTS.length; i++) {
		for (var j=0; j<STUDIOS.length; j++) {
			ast = ACCOMPANISTS[i]+'_'+STUDIOS[j];
			for (var k=0; k<slots; k++) {
				if (TIMES[i][j].length>0) {
					for (var n=0; n<TIMES[i][j].length; n++) {
						//console.log('hee')
						cstr+=pv[n]+'SPEC'+ast+k;
						if (n<TIMES[i][j].length-1) cstr+=' + ';
					}
					cstr += ' <= 1;\n';
				}
			}
		}
	}
	for (var i=0; i<ACCOMPANISTS.length; i++) {
		for (var j=0; j<STUDIOS.length; j++) {
			ast = ACCOMPANISTS[i]+'_'+STUDIOS[j];
			for (var k=0; k<slots-1; k++) {
				for (var n=0; n<TIMES[i][j].length-1; n++) {
					T = TIMES[i][j][n];
					for (var m=n+1; m<TIMES[i][j].length; m++) {
						cstr+=pv[n]+'SPEC'+ast+k+' + '+pv[m]+'SPEC'+ast+(k+1)+' <= 1;\n';
						cstr+=pv[m]+'SPEC'+ast+k+' + '+pv[n]+'SPEC'+ast+(k+1)+' <= 1;\n';
					}
				}
			}
		}
	}
	binstr=binstr.slice(0,binstr.length-2);
	binstr+=';';
	//cstr += 'aSPECDennis_Novak0 + aSPECDennis_Novak1 + aSPECDennis_Novak2 + aSPECDennis_Novak3 + aSPECDennis_Novak4 + aSPECDennis_Novak5 + aSPECDennis_Novak6 + aSPECDennis_Novak7 + aSPECDennis_Novak8 + aSPECDennis_Novak9 + aSPECDennis_Novak10 + aSPECDennis_Novak11 + aSPECDennis_Novak12 + aSPECDennis_Novak13 + aSPECDennis_Novak14 = 1;\n';
	
	//cstr += 'ZPECDennis_Novak0_0 + ZPECDennis_Novak0_1 + ZPECDennis_Novak1_1 + ZPECDennis_Novak1_2 + ZPECDennis_Novak2_2 + ZPECDennis_Novak2_3 + ZPECDennis_Novak3_3 + ZPECDennis_Novak3_4 + ZPECDennis_Novak4_4 + ZPECDennis_Novak4_5 + ZPECDennis_Novak5_5 + ZPECDennis_Novak5_6 + ZPECDennis_Novak6_6 + ZPECDennis_Novak6_7 + ZPECDennis_Novak7_7 + ZPECDennis_Novak7_8 + ZPECDennis_Novak8_8 + ZPECDennis_Novak8_9 + ZPECDennis_Novak9_9 + ZPECDennis_Novak9_10 + ZPECDennis_Novak10_10 + ZPECDennis_Novak10_11 + ZPECDennis_Novak11_11 + ZPECDennis_Novak11_12 + ZPECDennis_Novak12_12 + ZPECDennis_Novak12_13 + ZPECDennis_Novak13_13 + ZPECDennis_Novak13_14 + ZPECDennis_Novak14_14 + ZPECDennis_Novak14_15 = 2;\n';
	//cstr += 'ZPECDennis_Novak0_0 <= aSPECDennis_Novak0;\n';
	//cstr += 'ZPECDennis_Novak0_0 <= Dennis_Novak0;\n';
	//cstr += 'ZPECDennis_Novak0_0 >= aSPECDennis_Novak0 + Dennis_Novak0 - 1;\n';
	
	//for (var i=0; i<14; i++) {
	//	for (var j=i; j<i+2; j++) {
	//		cstr+='ZPECDennis_Novak'+i+'_'+j+' <= aSPECDennis_Novak'+i+';\n';
	//		cstr+='ZPECDennis_Novak'+i+'_'+j+' <= Dennis_Novak'+j+';\n';
	//		cstr+='ZPECDennis_Novak'+i+'_'+j+' >= aSPECDennis_Novak'+i+' + Dennis_Novak'+j+' - 1;\n';
	//	}
	//}
	
	//cstr += 'aSPECDennis_Novak0 = 1;\n';
	//cstr += 'aSPECDennis_Novak0 Dennis_Novak0 + aSPECDennis_Novak0 Dennis_Novak1 = 2;\n'
	
	/*var ast;
	var T;
	var pv = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'];
	for (var i=0; i<ACCOMPANISTS.length; i++) {
		for (var j=0; j<STUDIOS.length; j++) {
			ast = ACCOMPANISTS[i] + '_' + STUDIOS[j]; //identifier
			for (var n = 0; n<TIMES[i][j].length; n++) {
				T = TIMES[i][j][n];
				//console.log(TIMES[i][j].length)
				for (var z=0; z<slots-(T-1); z++) {
					if (T>1) {
						for (var k=z; k<(z+T); k++) {
							if (k!=z) cstr+= ' + ';
							cstr += pv[n] + 'SPEC' + ast + z + ' ' + ast + k;
							//if (k!=z) console.log('BOOTY')
							//console.log(z+', '+k);
							//if (k<(z+(T-1)-1)) cstr+=' + ';
						}
					} else {
						cstr += pv[n] + 'SPEC' + ast + z + ' ' + ast + z;
					}
					if (z<slots-(T-1)-1) cstr+=' + ';
				}
				cstr += ' = ' + T + ';\n';
				for (var z=0; z<slots-(T-1); z++) {
					cstr += pv[n] + 'SPEC' + ast + z;
					if (z<slots-(T-1)-1) cstr+= ' + ';
					else cstr+= ' = 1;\n';
				}
				//cstr += pv[n] + 'SPEC' + ast + '0 = ' + ast + ' 0;\n'; 
			}
		}
	}*/
	
	//one accompanist per time slot
	var tstr='';
	for (var z=0; z<slots; z++) {
		for (var i=0; i<STUDIOS.length; i++) {
			for (var j=0; j<ACCOMPANISTS.length; j++) {
				tstr += ACCOMPANISTS[j] + '_' + STUDIOS[i] + z;
				if (j!=(ACCOMPANISTS.length-1)) tstr+=' + ';
				else tstr+=' <= ';
			}
			tstr+='1;';
			tstr+='\n';
		}
	}
	//console.log(tstr);
	
	//accompanist can't be two places at one time
	var rstr='';
	for (var z=0; z<slots; z++) {
		for (var i=0; i<ACCOMPANISTS.length; i++) {
			for (var j=0; j<STUDIOS.length; j++) {
				rstr += ACCOMPANISTS[i] + '_' + STUDIOS[j] + z;
				if (j!=(STUDIOS.length-1)) rstr+=' + ';
				else rstr+=' <= ';
			}
			rstr+='1;';
			rstr+='\n';
		}
	}
	//console.log(rstr);
	var lpStr = cstr+tstr+rstr+'\n'+binstr;
	return lpStr;
}
