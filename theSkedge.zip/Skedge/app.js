var USERS=[]			// Users Memory Array

var express = require('express');
var app = express();
var fs = require('fs');
var async = require('async');
var opener = require('opener');
var cmd = require('node-cmd');

app.use(express.static(__dirname + '/public'));

var bodyParser = require('body-parser');
var cookieParser = require('cookie-parser')
app.use(cookieParser('sssshhhhh'))
//app.use(bodyParser({limit: '50mb'}));
app.use(bodyParser.json({limit:1024102420, type:'application/json'}));

global.SLOTS = 16;

var JD=false;
if (process.argv.length > 2) {
	for (var i = 2; i < process.argv.length; i++) {
		switch (process.argv[i]) {
			case '-d':
				JD=true;
				break;
			default:
				break;
		}
	}
}

var STUDIOS=['Hache','Hartgraves','Novak','Parrish','Ulen','Vassian'];
var ACCOMPANISTS=['Wang','McNally','Dennis','Quesada','Anderson','Choi','Ashley','Kayla','Eric','Joey','Grace'];

if (!JD) {
	//build equations
	var ps = require('./server/js/solver.js');
	//run equation builder
	var lpStr = ps.solver(null);
	//write .lp file
	fs.writeFile(__dirname+'/skedge.lp', lpStr, function(err) {
		if(err) {
			return console.log(err);
		}
		//return;
		//console.log("The .lp file was saved!");
		
		//run lp_solve
		console.log('running lp_solve');
		cmd.get('lp_solve.exe skedge.lp > skedge.lp.csv',function(err, data, stderr){
			displayTheShit();			
		});		
	});
} else {
	displayTheShit();
}

function displayTheShit() {
	//display solution
	fs.readFile(__dirname+'/skedge.lp.csv', 'utf8', function (err,data) {
		if (err) {
			return console.log(err);
		}
		var stuff = data.split('\n');
		//console.log(stuff)
		var newAry=[];
		var tmp;
		for (var i=0; i<stuff.length-1; i++) {
			if (stuff[i].length>1 && !(stuff[i][1]=='S' && stuff[i][2]=='P' && stuff[i][3]=='E' && stuff[i][4]=='C')) {
				stuff[i]=stuff[i].replace('\r','');
				if (stuff[i][stuff[i].length-1]==1) {
					tmp=stuff[i].slice(0,stuff[i].indexOf(' '));
					while(tmp.indexOf('\n')!=-1) tmp=tmp.replace('\n','');
					while(tmp.indexOf(';0')!=-1) tmp=tmp.replace(';0','');
					while(tmp.indexOf(';1')!=-1) tmp=tmp.replace(';1','');
					while(tmp.indexOf(';')!=-1) tmp=tmp.replace(';','');
					newAry.push(tmp);
					//console.log(stuff[i].split('_')[1][0]);
				}
			}
		}
		newAry.sort(function(a,b){return addASCII(a.split('_')[1]) - addASCII(b.split('_')[1])})
		//console.log(newAry)
		//build html chart
		//studios
		htmlString+='<table>\n<tr>\n';
		
		htmlString+='<th>Time</th>\n';
		for (var i=0; i<STUDIOS.length; i++) {
			htmlString+='<th>'+STUDIOS[i]+'</th>\n';
		}
		htmlString+='</tr>\n'
		//console.log(newAry);
		//schedule
		var times = ['3:30 - 3:40','3:40 - 3:50','3:50 - 4:00','4:00 - 4:10','4:10 - 4:20','4:20 - 4:30','4:30 - 4:40','4:40 - 4:50']; //,'4:34 - 4:42','4:42 - 4:50'];
		for (var i=0; i<global.SLOTS; i++) {
			htmlString+='<tr>\n';
			htmlString+='<td>'+i+'</td>\n';
			for (var j=0; j<STUDIOS.length; j++) {
				htmlString+='<td>';
				for (var z=0; z<newAry.length; z++) {
					if (newAry[z].indexOf(STUDIOS[j])!=-1) {
						if (newAry[z].split(STUDIOS[j])[1]==i)
							htmlString+=newAry[z].split('_')[0];
					}
				}
				if (htmlString[htmlString.length-1]=='>') htmlString+='N/A';
				htmlString+='</td>\n'
			}
			htmlString+='</tr>\n';
		}
		
		htmlString+='</table>\n</body>\n</html>';
		//for (var i=0; i<newAry.length; i++)
		//	console.log(newAry[i]);
		fs.writeFile(__dirname+'/skedge.html', htmlString, function(err) {
			if(err) {
				return console.log(err);
			}

			//console.log("The .html file was saved!");
			console.log("Opening schedule...");
			opener('skedge.html');
		});	
	});
}

var htmlString = "<!DOCTYPE html>\n<html>\n<head>\n<style>\ntable {font-family: arial, sans-serif;border-collapse: collapse;width: 100%;}\ntd, th {border: 1px solid #dddddd;text-align: left;padding: 8px;}\ntr:nth-child(even) {background-color: #dddddd;}\n</style>\n</head>\n<body>\n"

function addASCII(s) {
	var as=0;
	for (var i=0; i<s.length; i++) {
		as+=s.charCodeAt(i);
	}
	//console.log(as)
	return as
}
